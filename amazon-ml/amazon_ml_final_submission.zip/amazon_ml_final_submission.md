
<a href="https://colab.research.google.com/github/ankishb/fun-projects/blob/master/amazon_ml_final_submission.ipynb" target="_parent"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab"/></a>

To run this notebook put the data in directory and name the file path appropriately. In my case it is **amazon-ml/** directory , defined in following cell.


```python
file_path = 'amazon-ml/'
```


```python
from tqdm import tqdm
import pandas as pd
import numpy as np
tqdm.pandas()
import matplotlib.pyplot as plt
%matplotlib inline

import os, gc, json, operator, re
import seaborn as sns

import warnings
warnings.filterwarnings("ignore")

pd.set_option('display.max_rows', 200)
pd.set_option('display.max_columns', 200)


sns.set(context='notebook', style='whitegrid', 
        palette='deep', font='sans-serif', 
        font_scale=2, color_codes=True, rc=None)
```

Text preprocessing: 

1.   Convert all words to Lower Case 
2.   Replace shortcut words with thoer corresponding word, i used contraction mapping text file to do this.
3.   Extra Space removal
4.   Punctualtion removal, to do this, i have included some special punctuation too, based on the dataset.
5. Digit and other special character removal.

After all these step, it will give convergence of around 94.7% from 71.3% on glove embedding.




```python
train = pd.read_csv(file_path+'Dataset/train.csv')
test  = pd.read_csv(file_path+'Dataset/test.csv')
sub   = pd.read_csv(file_path+'Dataset/Sample_Submission.csv')
print(train.shape, test.shape, sub.shape)


train.rename(columns={'Review Text':'text', 'Review Title':'title'}, inplace=True)
test.rename(columns={'Review Text':'text', 'Review Title':'title'}, inplace=True)

df = train.append(test, ignore_index=True)
df['save_text']  = df['text']
df['save_title'] = df['title']

df['text']  = df['text'].str.lower()
df['title'] = df['title'].str.lower()

with open(file_path+'contraction_mapping.txt') as f:
    contraction_mapping = json.loads(f.read())

def correct_contraction(x, dic):
    for word in dic.keys():
        if word in x:
            x = x.replace(word, dic[word])
    return x

df['text']  = df['text'].progress_apply(lambda x: correct_contraction(x, contraction_mapping))
df['title'] = df['title'].progress_apply(lambda x: correct_contraction(x, contraction_mapping))


```

     49%|████▊     | 4129/8512 [00:00<00:00, 41277.25it/s]

    (5959, 3) (2553, 2) (5, 3)


    100%|██████████| 8512/8512 [00:00<00:00, 39935.30it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 118655.95it/s]



```python
with open(file_path+'punctuation.txt', 'r') as f:
    extra_punct = json.loads(f.read())

import string
my_punct = list(string.punctuation)
all_punct = list(set(my_punct + extra_punct))

special_punc_mappings = {"—": "-", "–": "-", "_": "-", '”': '"', "″": '"', '“': '"', '•': '.', '−': '-',
                         "’": "'", "‘": "'", "´": "'", "`": "'", '\u200b': ' ', '\xa0': ' ','،':'','„':'',
                         '…': ' ... ', '\ufeff': ''}

def spacing_punctuation(text):
    """
    add space before and after punctuation and symbols
    """
    for punc in all_punct:
        if punc in text:
            text = text.replace(punc, f' {punc} ')
    return text

def clean_special_punctuations(text):
    for punc in special_punc_mappings:
        if punc in text:
#             print(punc)
            text = text.replace(punc, special_punc_mappings[punc])
    return text



def preprocess(text):
    text = spacing_punctuation(text)
    text = clean_special_punctuations(text)
    return text


df["text"] = df["text"].progress_apply(preprocess)
df['text'] = df['text'].str.replace(r'\b\w\b','').str.replace(r'\s+', ' ')
df['text'].replace({r'[^\x00-\x7F]+':''}, regex=True, inplace=True)
df['text'].replace({'  ':' '}, regex=True, inplace=True)

df["title"] = df["title"].progress_apply(preprocess)
df['title'] = df['title'].str.replace(r'\b\w\b','').str.replace(r'\s+', ' ')
df['title'].replace({r'[^\x00-\x7F]+':''}, regex=True, inplace=True)
df['title'].replace({'  ':' '}, regex=True, inplace=True)

import re
def clean_text(text):
    text = text.lower()
    text = re.sub(r'@[a-zA-Z0-9_]+', '', text)   
    text = re.sub(r'https?://[A-Za-z0-9./]+', '', text)   
    text = re.sub(r'www.[^ ]+', '', text)  
    text = re.sub(r'[a-zA-Z0-9]*www[a-zA-Z0-9]*com[a-zA-Z0-9]*', '', text)  
    text = re.sub(r'[^a-zA-Z]', ' ', text)   
    text = [token for token in text.split() if len(token) > 2]
    text = ' '.join(text)
    return text

df['text']   = df['text'].progress_apply(clean_text)
df['title']  = df['title'].progress_apply(clean_text)

def clean_text(x):
    x = str(x)
    for punct in "/-'":
        x = x.replace(punct, ' ')
    for punct in '&':
        x = x.replace(punct, f' {punct} ')
    for punct in '?!.,"#$%\'()*+-/:;<=>@[\\]^_`{|}~' + '“”’':
        x = x.replace(punct, '')
    return x

df['text'] = df['text'].progress_apply(clean_text)
df['title'] = df['title'].progress_apply(clean_text)

train1 = df[:train.shape[0]]
test1  = df[train.shape[0]:]
train1.shape, test1.shape
```

    100%|██████████| 8512/8512 [00:00<00:00, 67509.61it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 101113.08it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 22837.27it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 89656.22it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 79016.96it/s]
    100%|██████████| 8512/8512 [00:00<00:00, 105172.36it/s]





    ((5959, 5), (2553, 5))



Combine duplicates row with same Review text and Review Title and prepare **multilabel target set** .


```python
train1['topic'] = train1['topic'].apply(lambda x: "_".join(x.split(" ")))
gp = train1.groupby(['text','title']).agg({
        "topic": lambda x: " ".join(x.values)
    })
train2 = pd.DataFrame(gp.reset_index())

test1['topic'] = 'null'
gp = test1.groupby(['text','title']).agg({
        "topic": lambda x: " ".join(x.values)
    })
test2 = pd.DataFrame(gp.reset_index())

# train2.head().append(test2.head())
print(train2.shape, test2.shape)
```

    (4210, 3) (1773, 3)



```python
train3 = pd.merge(train1[['text','title']], train2, how='left')
test3  = pd.merge(test1[['text','title']], test2, how='left')

train3['labels'] = train3['topic'].apply(lambda x: len(x.split(" ")))
test3['labels']  = test3['topic'].apply(lambda x: len(x.split(" ")))

# train3.head().append(test3.head())
print(train3.shape, test3.shape)
```

    (5959, 4) (2553, 4)


Prepare Label Encoding of class to digit


```python
df1 = train2.append(test2, ignore_index=True)

print("Old table : ", df.shape, train.shape, test.shape) 
print("New Table : ", df1.shape, train2.shape, test2.shape)


labels = train1['topic'].values

train['target'] = train['topic'].astype('category').cat.codes
train['target'] = train['target'].astype('int')

def get_mapping(df, col_name):
    cat_codes = df[col_name].astype('category')
    
    class_mapping = {}
    i = 0
    for col in cat_codes.cat.categories:
        class_mapping[col] = i
        i += 1
    
    class_mapping_reverse = {}
    for key, value in class_mapping.items():
        class_mapping_reverse[value] = key

    return class_mapping, class_mapping_reverse

cl_map, cl_map_inv = get_mapping(train, 'topic')


cl_map1 = {}
for key, value in cl_map.items():
    cl_map1["_".join(key.split(" "))] = value
    

```

    Old table :  (8512, 5) (5959, 3) (2553, 2)
    New Table :  (5983, 3) (4210, 3) (1773, 3)



```python
cl_map_inv
```




    {0: 'Allergic',
     1: 'Bad Taste/Flavor',
     2: 'Color and texture',
     3: 'Customer Issues',
     4: 'Customer Service',
     5: "Didn't Like",
     6: 'Expiry',
     7: 'False Advertisement',
     8: 'Hard to Chew',
     9: 'Inferior to competitors',
     10: 'Ingredients',
     11: 'Not Effective',
     12: 'Packaging',
     13: 'Pricing',
     14: 'Quality/Contaminated',
     15: 'Shipment and delivery',
     16: 'Smells Bad',
     17: 'Texture',
     18: 'Too Sweet',
     19: 'Too big to swallow',
     20: 'Wrong Product received'}




```python
fig, ax = plt.subplots(figsize=(18, 6))
sns.countplot(train['topic'], ax=ax)
for tick in ax.get_xticklabels():
    tick.set_rotation(90)
total = train.shape[0]
for p in ax.patches:
    height = p.get_height()
    ax.text(p.get_x()+p.get_width()/2., height + 3, '{:1.2f}'.format(height/total), ha="center")

ax.set_title("Classes Distribution of dataset")
```




    Text(0.5, 1.0, 'Classes Distribution of dataset')




![png](output_13_1.png)



```python
train_len = train['text'].apply(lambda x: len(x.split(" ")))
plt.scatter(range(train.shape[0]), train_len)
plt.title("word length distribution in Review Text")
```




    Text(0.5, 1.0, 'word length distribution in Review Text')




![png](output_14_1.png)



```python
def get_quantile(df, col, q1, q2):
    """compute quantile range
    args:
        col: col name
        q1: lower quantile percentile
        q2: upper quantile percentile
    """
    df1 = df[[col]].dropna()
    lower_bound = np.percentile(df1, q=q1)
    upper_bound = np.percentile(df1, q=q2)
    lower_bound = np.round(lower_bound,3)
    upper_bound = np.round(upper_bound, 3)
    min_ = np.round(np.min(df1[col]), 3)
    max_ = np.round(np.max(df1[col]), 3)
    print("Col: {4:<15} min: {0:<10} max: {1:<10} low: {2:<10} high: {3:<10}".format(min_, max_, lower_bound, upper_bound, col))

train['len'] = train['text'].apply(lambda x: len(x.split(" ")))
get_quantile(train, 'len', 5, 95)
get_quantile(train, 'len', 1, 96)
get_quantile(train, 'len', 1, 97)
get_quantile(train, 'len', 1, 98)
get_quantile(train, 'len', 1, 99)
train.drop('len', axis=1, inplace=True)
```

    Col: len             min: 1          max: 546        low: 5.0        high: 153.1     
    Col: len             min: 1          max: 546        low: 2.0        high: 164.0     
    Col: len             min: 1          max: 546        low: 2.0        high: 185.26    
    Col: len             min: 1          max: 546        low: 2.0        high: 215.0     
    Col: len             min: 1          max: 546        low: 2.0        high: 260.84    



```python
train['len'] = train['text'].apply(lambda x: len(x.split(" ")))

fig, ax = plt.subplots(3,7, figsize=(20,18))
axes = ax.flatten()
all_topics = list(train['topic'].unique())
for topic, ax_ in zip(all_topics, axes):
    sns.distplot(train[train['topic'] == topic]['len'], label=topic, ax=ax_)
    ax_.legend()
    ax_.set_title('samples: '+str(train[train['topic'] == topic].shape[0]))
    ax_.set_xlim([0,2500])
    ax_.set_ylim([0., 0.0040])
train.drop('len', axis=1, inplace=True)
```


![png](output_16_0.png)



```python
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
stopwords = set(STOPWORDS)

def show_wordcloud(data, title = None):
    wordcloud = WordCloud(
        background_color='black',
        stopwords=stopwords,
        max_words=200,
        max_font_size=40, 
        scale=3,
        random_state=1 # chosen at random by flipping a coin; it was heads
).generate(str(data))

    fig = plt.figure(1, figsize=(15, 15))
    plt.axis('off')
    if title: 
        fig.suptitle(title, fontsize=20)
        fig.subplots_adjust(top=2.3)

    plt.imshow(wordcloud)
    plt.show()
    return wordcloud


wc1 = show_wordcloud(train['text'],'Most Common Words from the whole corpus')
```


![png](output_17_0.png)



```python
fig, ax = plt.subplots(figsize=(18, 1))
sns.barplot(list(wc1.words_.keys())[:50], list(wc1.words_.values())[:50], ax=ax)
for tick in ax.get_xticklabels():
    tick.set_rotation(90)
    tick.set_fontsize(22)
ax.set_title("Most common occured words")
```




    Text(0.5, 1.0, 'Most common occured words')




![png](output_18_1.png)



```python

```


```python
wc1 = show_wordcloud(train['title'],'Most Common Words from the Title')
```


![png](output_20_0.png)



```python
fig, ax = plt.subplots(figsize=(22, 1))
sns.barplot(list(wc1.words_.keys())[:50], list(wc1.words_.values())[:50], ax=ax)
for tick in ax.get_xticklabels():
    tick.set_rotation(90)
    tick.set_fontsize(22)
ax.set_title("Most common occured words in Title")
```




    Text(0.5, 1.0, 'Most common occured words in Title')




![png](output_21_1.png)



```python
labels = train2['topic'].values
lt = np.zeros((df1.shape[0], 21))
j = -1
for key, value in cl_map1.items():
    j += 1
    for i, label in enumerate(labels):
#         print(label)
        if key in label:
            lt[i][j] = 1

print(lt.sum(axis=0))
l_table = pd.DataFrame(data=lt, columns=list(cl_map1.keys()))
l_table = l_table.astype('int')
print(l_table.shape)
# l_table.head()
```

    [ 567. 1192.  233.    8.  239.   31.  135.   37.    6.   44.  215.  605.
      466.  107.  712.  387.  123.  410.   97.  228.   99.]
    (5983, 21)



```python
len1 = l_table.sum(axis=1)
fig, ax = plt.subplots(1,2,figsize=(25,5))
print("class count: ", np.bincount(len1))
print("class wise:  ", np.bincount(train['target']))

sns.countplot(len1, ax=ax[0])
ax[0].set_title("label count distribution")
sns.countplot(train['topic'], ax=ax[1])
ax[1].set_title("class count distribution")
for tick in ax[1].get_xticklabels():
    tick.set_rotation(90)
total = train.shape[0]
for p in ax[1].patches:
    height = p.get_height()
    ax[1].text(p.get_x()+p.get_width()/2., height + 3, '{:1.2f}'.format(height/total), ha="center")
```

    class count:  [1773 2907  959  277   53   11    3]
    class wise:   [ 567 1194  234    8  239   31  136   37    6   44  216  611  467  107
      715  390  123  410   97  228   99]



![png](output_23_1.png)



```python

```


```python
import gc
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD, NMF

def tfidf_feature(train, test, col_name, min_df=3, analyzer='word', 
                  token_pattern=r'\w{1,}', ngram=3, stopwords='english', 
                  n_component=120, decom_flag=False, which_method='svd', 
                  max_features=None, feat_col_name='svd'):

    tfv = TfidfVectorizer(min_df=min_df,  max_features=max_features, 
                strip_accents='unicode', analyzer=analyzer, max_df=0.95, 
                token_pattern=token_pattern, ngram_range=(1, ngram), 
                use_idf=1, smooth_idf=1, sublinear_tf=1,
                stop_words = stopwords)

    complete_df = pd.concat([train[col_name], test[col_name]], axis=0)
#         return complete_df
#         print(complete_df.shape, complete_df.columns)

    tfv.fit(list(complete_df[:].values))

    if decom_flag is False:
        train_tfv =  tfv.transform(train[col_name].values.ravel()) 
        test_tfv  = tfv.transform(test[col_name].values.ravel())

        del complete_df
        gc.collect()
        return train_tfv, test_tfv, tfv
    else:
        complete_tfv = tfv.transform(complete_df[:].values.ravel())
        
        if which_method is 'svd':
            svd = TruncatedSVD(n_components=n_component)
            svd.fit(complete_tfv)
            complete_dec = svd.transform(complete_tfv)
        else:
            nmf = NMF(n_components=n_component, random_state=1234, alpha=0, l1_ratio=0)
            nmf.fit(complete_tfv)            
            complete_dec = nmf.fit_transform(complete_tfv)            
        
        
        complete_dec = pd.DataFrame(data=complete_dec)
        complete_dec.columns = [feat_col_name+'_'+str(i) for i in range(n_component)]

        train_dec = complete_dec.iloc[:train.shape[0]]
        test_dec = complete_dec.iloc[train.shape[0]:].reset_index(drop=True)

        del complete_dec, complete_df
        gc.collect()
        print("="*15, " done ", "="*15)
        return train_dec, test_dec, complete_tfv, tfv

def countvect_feature(train, test, col_name, min_df=3, 
                      analyzer='word', token_pattern=r'\w{1,}', 
                      ngram=3, stopwords='english', max_features=None):

    ctv = CountVectorizer(min_df=min_df,  max_features=max_features, 
                strip_accents='unicode', analyzer=analyzer, 
                token_pattern=token_pattern, ngram_range=(1, ngram), 
                stop_words = stopwords)

    complete_df = pd.concat([train[col_name], test[col_name]], axis=0)
    ctv.fit(list(complete_df[:].values))

    train_tf =  ctv.transform(train[col_name].values.ravel()) 
    test_tf  = ctv.transform(test[col_name].values.ravel())

    del complete_df
    gc.collect()
    return train_tf, test_tf, ctv


def get_count_vectorizer(df, col_name, min_df=3, analyzer='word', stopwords='english', 
                     token_pattern=r'\w{1,}', ngram=3, max_features=None):
    ctv = CountVectorizer(min_df=min_df,  max_features=max_features, 
                strip_accents='unicode', analyzer=analyzer, 
                token_pattern=token_pattern, ngram_range=(1, ngram), 
                stop_words = stopwords)

    ctv.fit(list(df[col_name].values))

    df_new =  ctv.transform(df[col_name].values.ravel()) 
    return df_new


def get_tfidf_feature(df, col_name, min_df=3, analyzer='word', stopwords='english',
                  token_pattern=r'\w{1,}', ngram=3, max_features=None):

    tfv = TfidfVectorizer(min_df=min_df,  max_features=max_features, 
                strip_accents='unicode', analyzer=analyzer, max_df=0.95, 
                token_pattern=token_pattern, ngram_range=(1, ngram), 
                use_idf=1, smooth_idf=1, sublinear_tf=1,
                stop_words = stopwords)

    tfv.fit(list(df[col_name].values))
    df_new =  tfv.transform(df[col_name].values.ravel()) 
    
    return df_new


```


```python
!wget http://nlp.stanford.edu/data/glove.6B.zip
```

    --2019-08-11 15:08:24--  http://nlp.stanford.edu/data/glove.6B.zip
    Resolving nlp.stanford.edu (nlp.stanford.edu)... 171.64.67.140
    Connecting to nlp.stanford.edu (nlp.stanford.edu)|171.64.67.140|:80... connected.
    HTTP request sent, awaiting response... 302 Found
    Location: https://nlp.stanford.edu/data/glove.6B.zip [following]
    --2019-08-11 15:08:24--  https://nlp.stanford.edu/data/glove.6B.zip
    Connecting to nlp.stanford.edu (nlp.stanford.edu)|171.64.67.140|:443... connected.
    HTTP request sent, awaiting response... 301 Moved Permanently
    Location: http://downloads.cs.stanford.edu/nlp/data/glove.6B.zip [following]
    --2019-08-11 15:08:24--  http://downloads.cs.stanford.edu/nlp/data/glove.6B.zip
    Resolving downloads.cs.stanford.edu (downloads.cs.stanford.edu)... 171.64.64.22
    Connecting to downloads.cs.stanford.edu (downloads.cs.stanford.edu)|171.64.64.22|:80... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 862182613 (822M) [application/zip]
    Saving to: ‘glove.6B.zip’
    
    glove.6B.zip        100%[===================>] 822.24M  88.3MB/s    in 11s     
    
    2019-08-11 15:08:35 (74.4 MB/s) - ‘glove.6B.zip’ saved [862182613/862182613]
    



```python
!unzip glove.6B.zip
```

    Archive:  glove.6B.zip
      inflating: glove.6B.50d.txt        
      inflating: glove.6B.100d.txt       
      inflating: glove.6B.200d.txt       
      inflating: glove.6B.300d.txt       



```python
!ls
```

    fun-projects	   glove.6B.200d.txt  glove.6B.50d.txt	sample_data
    glove.6B.100d.txt  glove.6B.300d.txt  glove.6B.zip



```python
embeddings_index = {}
f = open('glove.6B.300d.txt')
for line in tqdm(f):
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs
f.close()

print('Found %s word vectors.' % len(embeddings_index))
```

    400000it [00:31, 12517.90it/s]

    Found 400000 word vectors.


    



```python
print(train2.shape, test2.shape)

df1['topic1'] = df1['topic']
df1['topic'] = df1['topic1'].apply(lambda x: x.split(" ")[0])
train4 = df1[:train2.shape[0]]
test4  = df1[train2.shape[0]:]
train4.drop('topic1', axis=1, inplace=True)
test4.drop('topic1', axis=1, inplace=True)
print(train4.shape, test4.shape)


df3 = train4.append(test4, ignore_index=True)
print(df3.shape)

```

    (4210, 3) (1773, 3)
    (4210, 3) (1773, 3)
    (5983, 3)



```python
train4.shape, df3.shape, train4.columns
```




    ((4210, 3), (5983, 3), Index(['text', 'title', 'topic'], dtype='object'))




```python
train4['target'] = train4['topic'].astype('category').cat.codes
train4['target'] = train4['target'].astype('int')
```


```python

```

**Topic Modelling for word (topic) analysis**


1.   With $10$ components 
2.   With $21$ components 

In the following cell, we see interesting topics and their distribution over the all dataset, gives some insight of **Product Review** at higher level. Each topic(with 10 components) have unique and pretty good topics related to classes.





```python
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation

cv = CountVectorizer(max_df=0.97,min_df=2,stop_words='english')
term_matrix = cv.fit_transform(df3['title'])
# print(term_matrix)
```


```python

```

topic moddeling using 10 component


```python
lda = LatentDirichletAllocation(n_components=10, n_jobs=4)
lda.fit(term_matrix)

topic_word_dict = {}
for index,topic in enumerate(lda.components_):
    words = [cv.get_feature_names()[i] for i in topic.argsort()[-5:]]
    topic_word_dict[index] = words
    print('Top words for topic {}'.format(index))
    print(words)
    print('-'*120)
```

    Top words for topic 0
    ['sent', 'bottle', 'good', 'broken', 'buy']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 1
    ['poor', 'like', 'quality', 'tastes', 'does']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 2
    ['delivered', 'wrong', 'product', 'item', 'received']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 3
    ['receive', 'expired', 'packaging', 'did', 'product']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 4
    ['reaction', 'allergic', 'delivery', 'work', 'did']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 5
    ['price', 'awful', 'waste', 'just', 'money']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 6
    ['good', 'pill', 'got', 'pills', 'flavor']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 7
    ['damaged', 'shipping', 'stomach', 'brand', 'arrived']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 8
    ['good', 'smell', 'horrible', 'bad', 'taste']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 9
    ['oil', 'nasty', 'disappointed', 'beware', 'great']
    ------------------------------------------------------------------------------------------------------------------------



```python
ts_feat = term_matrix[-test4.shape[0]:]
print(ts_feat.shape)
topics_ = lda.transform(ts_feat)

test_topics = []
for topic in topics_:
    test_topics.append(np.argsort(topic)[-1])
    
sns.countplot(test_topics)
plt.title("topics distribution")
```




    Text(0.5, 1.0, 'topics distribution')




![png](output_39_1.png)


topic modelling using 21 component and then we cluser the topics


```python
lda = LatentDirichletAllocation(n_components=21, n_jobs=4)
lda.fit(term_matrix)

topic_word_dict = {}
for index,topic in enumerate(lda.components_):
    words = [cv.get_feature_names()[i] for i in topic.argsort()[-5:]]
    topic_word_dict[index] = words
    print('Top words for topic {}'.format(index))
    print(words)
    print('-'*120)
```

    Top words for topic 0
    ['return', 'meh', 'nasty', 'delivered', 'delivery']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 1
    ['flavor', 'new', 'huge', 'yuck', 'stomach']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 2
    ['purchase', 'love', 'got', 'package', 'shipping']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 3
    ['works', 'sent', 'wrong', 'item', 'horrible']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 4
    ['used', 'sure', 'difference', 'expiration', 'date']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 5
    ['effective', 'open', 'seal', 'awful', 'broken']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 6
    ['strong', 'disappointed', 'brand', 'gross', 'terrible']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 7
    ['best', 'tasting', 'missing', 'bottle', 'order']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 8
    ['rancid', 'worst', 'okay', 'large', 'damaged']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 9
    ['weird', 'great', 'received', 'flavor', 'product']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 10
    ['big', 'work', 'waste', 'money', 'does']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 11
    ['time', 'like', 'smells', 'just', 'smell']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 12
    ['day', 'results', 'price', 'expensive', 'help']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 13
    ['better', 'disgusting', 'packaging', 'like', 'tastes']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 14
    ['recommend', 'ordered', 'like', 'bad', 'taste']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 15
    ['nope', 'texture', 'sick', 'buy', 'bad']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 16
    ['chalky', 'caused', 'fishy', 'hard', 'sweet']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 17
    ['makes', 'vitamins', 'arrived', 'poor', 'quality']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 18
    ['ingredients', 'beware', 'receive', 'work', 'did']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 19
    ['stale', 'sticky', 'stuck', 'vitamin', 'pills']
    ------------------------------------------------------------------------------------------------------------------------
    Top words for topic 20
    ['reaction', 'allergic', 'expired', 'product', 'good']
    ------------------------------------------------------------------------------------------------------------------------



```python
ts_feat = term_matrix[:-test4.shape[0]]
print(ts_feat.shape)
topics_ = lda.transform(ts_feat)

test_topics = []
for topic in topics_:
    test_topics.append(np.argsort(topic)[-1])
    
    
fig, ax = plt.subplots(1,1, figsize=(18,5))    
sns.countplot(test_topics, ax=ax)
ax.set_title("topics distribution for training dataset")
```

    (4210, 1245)





    Text(0.5, 1.0, 'topics distribution for training dataset')




![png](output_42_2.png)



```python
ts_feat = term_matrix[-test4.shape[0]:]
print(ts_feat.shape)
topics_ = lda.transform(ts_feat)

test_topics = []
for topic in topics_:
    test_topics.append(np.argsort(topic)[-1])
    
    
fig, ax = plt.subplots(1,1, figsize=(18,5))    
sns.countplot(test_topics, ax=ax)
ax.set_title("topics distribution")
```

    (1773, 1245)





    Text(0.5, 1.0, 'topics distribution')




![png](output_43_2.png)



```python
from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(
    df3[:train4.shape[0]][['text','title']], train4['target'], 
    stratify=train4['target'], 
    test_size=0.25
)
X_train.shape, Y_train.shape, X_test.shape, Y_test.shape
```




    ((3157, 2), (3157,), (1053, 2), (1053,))




```python

```

Analysis of review using word-embedding

1.    prepare sent2vect usinf glove-300-embedding vector
2.    run tsne on top of these feature, we analyze the resukt in the following block. Note: we used pretrained embedding direclty.

For **TSNE**, we use

-  Used Preplexity of 30 and 90 to get good visualization. It doesn reveal anything. I used different approach to get inference, results can be analyzed in the last cell block of this notebook.
-  Mean of each class are seperate by a margin, which is a good sign of training neural network using embedding of words.


```python

```


```python
!pip install nltk
import nltk
nltk.download('stopwords')
nltk.download('punkt')
```

    Requirement already satisfied: nltk in /usr/local/lib/python3.6/dist-packages (3.2.5)
    Requirement already satisfied: six in /usr/local/lib/python3.6/dist-packages (from nltk) (1.12.0)
    [nltk_data] Downloading package stopwords to /root/nltk_data...
    [nltk_data]   Unzipping corpora/stopwords.zip.
    [nltk_data] Downloading package punkt to /root/nltk_data...
    [nltk_data]   Unzipping tokenizers/punkt.zip.





    True




```python
from nltk import word_tokenize
from nltk.corpus import stopwords
stop_words = stopwords.words('english')

# this function creates a normalized vector for the whole sentence
def sent2vec(s):
    words = str(s).lower()#.decode('utf-8')
    words = word_tokenize(words)
    words = [w for w in words if not w in stop_words]
    words = [w for w in words if w.isalpha()]
    M = []
    for w in words:
        try:
            M.append(embeddings_index[w])
        except:
            continue
    M = np.array(M)
    v = M.sum(axis=0)
    if type(v) != np.ndarray:
        return np.zeros(300)
    return v / np.sqrt((v ** 2).sum())

# create sentence vectors using the above function for training and validation set
xtrain_glove = [sent2vec(x) for x in X_train['text']]
xvalid_glove = [sent2vec(x) for x in X_test['text']]
np.array(xtrain_glove).shape, np.array(xvalid_glove).shape
```




    ((3157, 300), (1053, 300))




```python
np.concatenate([xtrain_glove, xvalid_glove], axis=0).shape
```




    (4210, 300)




```python
from sklearn.manifold import TSNE
tsne = TSNE(n_components=2, perplexity=30)
mapping_tsne = tsne.fit_transform(np.concatenate([xtrain_glove, xvalid_glove], axis=0))
mapping_tsne.shape
```




    (4210, 2)




```python
fig, ax = plt.subplots(1,1, figsize=(16,5))
ax.scatter(mapping_tsne[:,0], mapping_tsne[:,1], c=train4['target'])
ax.set_title("class distribution plot of review text using TSNE with preplxity of 30")
```




    <matplotlib.collections.PathCollection at 0x7f12b88f3828>




![png](output_52_1.png)


TSNE on embedding of sentence doesn't give any information, if seemed a messy distribution


```python
from sklearn.manifold import TSNE
tsne = TSNE(n_components=2, perplexity=30)
mapping_tsne = tsne.fit_transform(np.concatenate([xtrain_glove, xvalid_glove], axis=0))
mapping_tsne.shape
```


```python
fig, ax = plt.subplots(1,1, figsize=(16,5))
ax.scatter(mapping_tsne[:,0], mapping_tsne[:,1], c=train4['target'])
ax.set_title("class distribution plot of review text using TSNE with preplxity of 90")
```




    Text(0.5, 1.0, 'class distribution plot of review text using TSNE')




![png](output_55_1.png)



```python
topics_mean = []
for topic in train4['topic'].unique():
    topics_mean.append(mapping_tsne[train4.topic == topic].mean(0))
```


```python
topics_mean = np.array(topics_mean).reshape(-1,2)
fig, ax = plt.subplots(1,1, figsize=(16,5))

for i,topic in enumerate(train4['topic'].unique()):
    ax.scatter(topics_mean[i,0], topics_mean[i,1], label=topic)
#                c=train4['target'].unique(), labels=train4['topic'].unique())
ax.legend()
ax.set_title("class distribution mean plot of review text")
```




    Text(0.5, 1.0, 'class distribution mean plot of review text')




![png](output_57_1.png)



```python
del xtrain_glove, xvalid_glove
gc.collect()
```




    0




```python

```


```python
df1.shape, df3.shape, df1.columns, df3.columns
```




    ((5983, 4),
     (5983, 3),
     Index(['text', 'title', 'topic', 'topic1'], dtype='object'),
     Index(['text', 'title', 'topic'], dtype='object'))




```python

```

Feature Extraction

1.   Count Vectorizer Fetaures
2.   term Frequency Inverse Document Frequency Features

I extract feature using $4$ ngram as **1,2,3,5**.


```python
print("="*15, "count-vect","="*15)
print("="*15, "text","="*15)
cvect_text_store = []
for ngram in [1,2,3,5]:
#     if ngram < 11 : continue
    cvect = get_count_vectorizer(df3, 'text', ngram)
    print(cvect.shape, end=" ")
    cvect_text_store.append(cvect)
print()
print("="*15, "title","="*15)
cvect_title_store = []
for ngram in [1,2,3,5]:
#     if ngram < 11 : continue
    cvect = get_count_vectorizer(df3, 'title', ngram)
    print(cvect.shape, end=" ")
    cvect_title_store.append(cvect)
    
print()
print("="*30)    
print("="*15, "tfidf","="*15)
print("="*15, "text","="*15)

tfidf_text_store = []
for ngram in [1,2,3,5]:
    tfidf = get_tfidf_feature(df3, 'text', ngram=ngram)
    print(tfidf.shape, end=" ")
    tfidf_text_store.append(tfidf)
    
print()
print("="*15, "title","="*15)
tfidf_title_store = []
for ngram in [1,2,3,5]:
    tfidf = get_tfidf_feature(df3, 'text', ngram=ngram)
    print(tfidf.shape, end=" ")
    tfidf_title_store.append(tfidf)
```

    =============== count-vect ===============
    =============== text ===============
    (5983, 190846) (5983, 18056) (5983, 8630) (5983, 4380) 
    =============== title ===============
    (5983, 14131) (5983, 2151) (5983, 1259) (5983, 702) 
    ==============================
    =============== tfidf ===============
    =============== text ===============
    (5983, 3684) (5983, 8192) (5983, 8630) (5983, 8750) 
    =============== title ===============
    (5983, 3684) (5983, 8192) (5983, 8630) (5983, 8750) 


```python

```

**Model Building and their Analysis**

1.   Multinomial Naive Bayes Classifier
2.   Logisitic regression
3.   Stochastic Gradient Descent Classifier
4.   Support Vector Machine
5.   OneVsRest and Multiclass

Inference: Multinomial Naive Bayes Classifier performs very well on Using count vectorizer feature, it can be analyzed fro folowing performance analysis.



```python
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split    

acc_table = []

for i, data in enumerate(cvect_text_store):
    train_  = data[:train4.shape[0]]
    target_ = l_table[:train4.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf = MultinomialNB().fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Classification score using count-vect feature on text")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Allergic</th>
      <th>Bad_Taste/Flavor</th>
      <th>Color_and_texture</th>
      <th>Customer_Issues</th>
      <th>Customer_Service</th>
      <th>Didn't_Like</th>
      <th>Expiry</th>
      <th>False_Advertisement</th>
      <th>Hard_to_Chew</th>
      <th>Inferior_to_competitors</th>
      <th>Ingredients</th>
      <th>Not_Effective</th>
      <th>Packaging</th>
      <th>Pricing</th>
      <th>Quality/Contaminated</th>
      <th>Shipment_and_delivery</th>
      <th>Smells_Bad</th>
      <th>Texture</th>
      <th>Too_Sweet</th>
      <th>Too_big_to_swallow</th>
      <th>Wrong_Product_received</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.916429</td>
      <td>0.884141</td>
      <td>0.955366</td>
      <td>0.997151</td>
      <td>0.941121</td>
      <td>0.991453</td>
      <td>0.974359</td>
      <td>0.990503</td>
      <td>0.997151</td>
      <td>0.987654</td>
      <td>0.953466</td>
      <td>0.882241</td>
      <td>0.949668</td>
      <td>0.973409</td>
      <td>0.865147</td>
      <td>0.933523</td>
      <td>0.971510</td>
      <td>0.924976</td>
      <td>0.976258</td>
      <td>0.947768</td>
      <td>0.976258</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.925926</td>
      <td>0.882241</td>
      <td>0.954416</td>
      <td>0.996201</td>
      <td>0.939221</td>
      <td>0.990503</td>
      <td>0.985755</td>
      <td>0.988604</td>
      <td>0.998101</td>
      <td>0.989554</td>
      <td>0.952517</td>
      <td>0.908832</td>
      <td>0.933523</td>
      <td>0.968661</td>
      <td>0.883191</td>
      <td>0.934473</td>
      <td>0.968661</td>
      <td>0.927825</td>
      <td>0.974359</td>
      <td>0.953466</td>
      <td>0.981007</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.917379</td>
      <td>0.886040</td>
      <td>0.966762</td>
      <td>0.996201</td>
      <td>0.941121</td>
      <td>0.991453</td>
      <td>0.987654</td>
      <td>0.990503</td>
      <td>0.997151</td>
      <td>0.987654</td>
      <td>0.956315</td>
      <td>0.903134</td>
      <td>0.927825</td>
      <td>0.967711</td>
      <td>0.865147</td>
      <td>0.941121</td>
      <td>0.974359</td>
      <td>0.934473</td>
      <td>0.975309</td>
      <td>0.966762</td>
      <td>0.984805</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.905983</td>
      <td>0.879392</td>
      <td>0.946819</td>
      <td>0.997151</td>
      <td>0.932574</td>
      <td>0.992403</td>
      <td>0.992403</td>
      <td>0.992403</td>
      <td>0.998101</td>
      <td>0.988604</td>
      <td>0.953466</td>
      <td>0.891738</td>
      <td>0.915480</td>
      <td>0.969611</td>
      <td>0.872745</td>
      <td>0.930674</td>
      <td>0.966762</td>
      <td>0.932574</td>
      <td>0.972460</td>
      <td>0.965812</td>
      <td>0.976258</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_66_1.png)



```python
acc_table = []

for i, data in enumerate(cvect_title_store):
    train_  = data[:train1.shape[0]]
    target_ = l_table[:train1.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf = MultinomialNB().fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Classification score using count-vect feature on titles")
```




    Text(0.5, 1.0, 'Classification score using count-vect feature on titles')




![png](output_67_1.png)



```python
acc_table = []

for i, data in enumerate(tfidf_title_store):
    train_  = data[:train1.shape[0]]
    target_ = l_table[:train1.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf = MultinomialNB().fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Classification score using tfidf feature on title")
```




    Text(0.5, 1.0, 'Classification score using tfidf feature on title')




![png](output_68_1.png)



```python
acc_table = []

for i, data in enumerate(tfidf_text_store):
    train_  = data[:train1.shape[0]]
    target_ = l_table[:train1.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf = MultinomialNB().fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Classification score using tfidf feature on text")
```




    Text(0.5, 1.0, 'Classification score using tfidf feature on text')




![png](output_69_1.png)



```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    


acc_table = []
clf = LogisticRegression(penalty='l2', dual=False, 
    C=0.1, fit_intercept=True, intercept_scaling=1, class_weight='balanced', 
    random_state=1234, max_iter=100, multi_class='warn', verbose=0, n_jobs=-1)

for i, data in enumerate(cvect_title_store):
    train_  = data[:train2.shape[0]]
    target_ = l_table[:train2.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf.fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Logistic Regression score using count vect feature on text")
```




    Text(0.5, 1.0, 'Logistic Regression score using tfidf feature on text')




![png](output_70_1.png)



```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    


acc_table = []
clf = LogisticRegression(penalty='l2', dual=False, 
    C=0.1, fit_intercept=True, intercept_scaling=1, class_weight='balanced', 
    random_state=1234, max_iter=100, multi_class='warn', verbose=0, n_jobs=-1)

for i, data in enumerate(tfidf_text_store):
    train_  = data[:train2.shape[0]]
    target_ = l_table[:train2.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf.fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
# acc_table.columns = l_table.columns
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Logistic Regression score using tfidf feature on text")
```




    Text(0.5, 1.0, 'Logistic Regression score using tfidf feature on text')




![png](output_71_1.png)



```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    


acc_table = []
clf = LogisticRegression(penalty='l2', dual=False, 
    C=0.1, fit_intercept=True, intercept_scaling=1, class_weight='balanced', 
    random_state=1234, max_iter=100, multi_class='warn', verbose=0, n_jobs=-1)

for i, data in enumerate(tfidf_title_store):
    train_  = data[:train2.shape[0]]
    target_ = l_table[:train2.shape[0]]
    
    accs = []
    for cls in target_.columns:
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf.fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
    acc_table.append(accs)
    
# acc_table.columns = l_table.columns
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("Logistic Regression score using tfidf feature on title")
```




    Text(0.5, 1.0, 'Logistic Regression score using tfidf feature on title')




![png](output_72_1.png)



```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    
from sklearn.linear_model import SGDClassifier
import warnings
warnings.filterwarnings("ignore")

acc_table = []
preds = []
clf = SGDClassifier(loss='log', penalty='elasticnet', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, 
                        max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=4, 
                        random_state=1337, learning_rate='optimal', eta0=0.0, power_t=0.5,
                        early_stopping=True, validation_fraction=0.25, n_iter_no_change=5, 
                        class_weight='balanced', warm_start=False, average=False)

for i, data in enumerate(tfidf_text_store):
    train_  = data[:train2.shape[0]]
    target_ = l_table[:train2.shape[0]]
#     test_   = data[train2.shape[0]:]
    
    
    accs = []
    for cls in target_.columns:
        if(cls == 'topic'): continue
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf.fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
#         pred = clf.predict_proba(test_)
#         print(cls)
#         preds.append(pred[:,1])
    acc_table.append(accs)
    
    
# acc_table.columns = l_table.columns
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("SGD classifiers score using tfidf feature on text")
```




    Text(0.5, 1.0, 'SGD classifiers score using tfidf feature on text')




![png](output_73_1.png)



```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    
from sklearn.linear_model import SGDClassifier
import warnings
warnings.filterwarnings("ignore")

acc_table = []
preds = []
clf = SGDClassifier(loss='log', penalty='elasticnet', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, 
                        max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=4, 
                        random_state=1337, learning_rate='optimal', eta0=0.0, power_t=0.5,
                        early_stopping=True, validation_fraction=0.25, n_iter_no_change=5, 
                        class_weight='balanced', warm_start=False, average=False)

for i, data in enumerate(tfidf_title_store):
    train_  = data[:train2.shape[0]]
    target_ = l_table[:train2.shape[0]]
#     test_   = data[train2.shape[0]:]
    
    
    accs = []
    for cls in target_.columns:
        if(cls == 'topic'): continue
        
        X_train, X_test, Y_train, Y_test = train_test_split(
            train_, target_[cls], 
            stratify=target_[cls], 
            test_size=0.25
        )
        clf.fit(X_train, Y_train)
        score = clf.score(X_test, Y_test)
#         print('tfidf {:<25} acc: {:.4f}'.format(cls, score))
        accs.append(score)
#         pred = clf.predict_proba(test_)
#         print(cls)
#         preds.append(pred[:,1])
    acc_table.append(accs)
    
    
# acc_table.columns = l_table.columns
acc_table = pd.DataFrame(data=acc_table, columns=l_table.columns)
plt.plot(acc_table.apply(lambda x: np.mean(x), axis=1), '.')
plt.title("SGD classifiers score using tfidf feature on title")
```




    Text(0.5, 1.0, 'SGD classifiers score using tfidf feature on title')




![png](output_74_1.png)


Let's build some tree based model on top of SVD feature of text data


```python

```


```python
X_train.shape, X_test.shape, Y_train.shape, Y_test.shape
```




    ((3157, 8750), (1053, 8750), (3157,), (1053,))




```python
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split    
import warnings
warnings.filterwarnings("ignore")

logistic_reg = LogisticRegression(penalty='l2', dual=False, 
    C=0.1, fit_intercept=True, intercept_scaling=1, class_weight='balanced', 
    random_state=1234, max_iter=100, multi_class='warn', verbose=0, n_jobs=-1)

for i, data in enumerate(tfidf_text_store):
    train_ = data[:train4.shape[0]]
    X_train, X_test, Y_train, Y_test = train_test_split(
        train_, train4['target'], 
        stratify=train4['target'], 
        test_size=0.25
    )
    clf = logistic_reg.fit(X_train, Y_train)
#     print("log-reg "+str(i), clf.score(X_test, Y_test))
    print('tfidf {:<10} acc: {:.4f}'.format(str(i), clf.score(X_test, Y_test)))

print("="*30)
for i, data in enumerate(cvect_text_store):
    train_ = data[:train4.shape[0]]
    X_train, X_test, Y_train, Y_test = train_test_split(
        train_, train4['target'], 
        stratify=train4['target'], 
        test_size=0.25
    )
    clf = logistic_reg.fit(X_train, Y_train)
#     print("log-reg "+str(i), clf.score(X_test, Y_test))
    print('cvect {:<10} acc: {:.4f}'.format(str(i), clf.score(X_test, Y_test)))
```

    tfidf 0          acc: 0.5916
    tfidf 1          acc: 0.6249
    tfidf 2          acc: 0.6002
    tfidf 3          acc: 0.6277
    ==============================
    count-vect 0          acc: 0.6429
    count-vect 1          acc: 0.6524
    count-vect 2          acc: 0.6410
    count-vect 3          acc: 0.6277



```python
data = cvect_text_store[1]
train_ = data[:train4.shape[0]]
X_train, X_test, Y_train, Y_test = train_test_split(
    train_, train4['target'], 
    stratify=train4['target'], 
    test_size=0.25
)
clf = logistic_reg.fit(X_train, Y_train)
#     print("log-reg "+str(i), clf.score(X_test, Y_test))
print('count-vect {:<10} acc: {:.4f}'.format(str(i), clf.score(X_test, Y_test)))

test_ = data[train4.shape[0]:]
pred_log = clf.predict(test_)
print(pred_log.shape)


test4.reset_index(drop=True)
test4['topic'] = pred_log
final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
final1 = final1[['save_text','save_title','target']]
final1.columns = sub.columns
print(final1.shape)

if not os.path.exists('submission'):
    os.makedirs('submission')
final1.to_csv('submission/cvect_log_reg.csv',index=None)
print("saved successfully")
```

    count-vect 0          acc: 0.6458
    (1773,)
    (2553, 3)
    saved successfully



```python
from sklearn.linear_model import SGDClassifier

data = cvect_text_store[1]
train_ = data[:train4.shape[0]]
X_train, X_test, Y_train, Y_test = train_test_split(
    train_, train4['target'], 
    stratify=train4['target'], 
    test_size=0.25
)

sgd_clf = SGDClassifier(loss='log', penalty='elasticnet', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, 
                        max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=4, 
                        random_state=1337, learning_rate='optimal', eta0=0.0, power_t=0.5,
                        early_stopping=True, validation_fraction=0.25, n_iter_no_change=5, 
                        class_weight='balanced', warm_start=False, average=False)
sgd_clf.fit(X_train, Y_train)
print("SGD score: ", sgd_clf.score(X_test, Y_test))

test_ = data[train4.shape[0]:]
pred_sgd = sgd_clf.predict(test_)
print(pred_sgd.shape)


test4.reset_index(drop=True)
test4['topic'] = pred_sgd
final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
final1 = final1[['save_text','save_title','target']]
final1.columns = sub.columns
print(final1.shape)

if not os.path.exists('submission'):
    os.makedirs('submission')
final1.to_csv('submission/cvect_sgd_clf.csv',index=None)
print("saved successfully")

#######


fig, ax = plt.subplots(1,1, figsize=(18, 4))
sns.countplot(pred, color='k', ax=ax)
sns.countplot(Y_test, color='r', ax=ax, alpha=0.2)
ax.set_title("Error Analysis on validation dataset")

```

    SGD score:  0.5859449192782527
    (1773,)
    (2553, 3)
    saved successfully





    Text(0.5, 1.0, 'Error Analysis on validation dataset')




![png](output_80_2.png)



```python
for i, data in enumerate(tfidf_text_store):
    train_ = data[:train4.shape[0]]
    X_train, X_test, Y_train, Y_test = train_test_split(
        train_, train4['target'], 
        stratify=train4['target'], 
        test_size=0.25
    )
    
    sgd_clf = SGDClassifier(loss='log', penalty='elasticnet', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, 
                        max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=4, 
                        random_state=1337, learning_rate='optimal', eta0=0.0, power_t=0.5,
                        early_stopping=True, validation_fraction=0.25, n_iter_no_change=5, 
                        class_weight='balanced', warm_start=False, average=False)
    sgd_clf.fit(X_train, Y_train)
#     sgd_clf.score(X_test, Y_test)

#     clf = logistic_reg.fit(X_train, Y_train)
#     print("log-reg "+str(i), clf.score(X_test, Y_test))
    print('tfidf {:<10} acc: {:.4f}'.format(str(i), sgd_clf.score(X_test, Y_test)))
```

    tfidf 0          acc: 0.6657
    tfidf 1          acc: 0.6524
    tfidf 2          acc: 0.6857
    tfidf 3          acc: 0.6695



```python
from sklearn.linear_model import SGDClassifier

data = tfidf_text_store[2]
train_ = data[:train4.shape[0]]
X_train, X_test, Y_train, Y_test = train_test_split(
    train_, train4['target'], 
    stratify=train4['target'], 
    test_size=0.25
)

sgd_clf = SGDClassifier(loss='log', penalty='elasticnet', alpha=0.0001, l1_ratio=0.15, fit_intercept=True, 
                        max_iter=1000, tol=0.001, shuffle=True, verbose=0, epsilon=0.1, n_jobs=4, 
                        random_state=1337, learning_rate='optimal', eta0=0.0, power_t=0.5,
                        early_stopping=True, validation_fraction=0.25, n_iter_no_change=5, 
                        class_weight='balanced', warm_start=False, average=False)
sgd_clf.fit(X_train, Y_train)
print("SGD score: ", sgd_clf.score(X_test, Y_test))

test_ = data[train4.shape[0]:]
pred_sgd1 = sgd_clf.predict(test_)
print(pred_sgd1.shape)


test4.reset_index(drop=True)
test4['topic'] = pred_sgd1
final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
final1 = final1[['save_text','save_title','target']]
final1.columns = sub.columns
print(final1.shape)

if not os.path.exists('submission'):
    os.makedirs('submission')
final1.to_csv('submission/tfidf_sgd_clf.csv',index=None)
print("saved successfully")

#######


fig, ax = plt.subplots(1,1, figsize=(18, 4))
sns.countplot(pred, color='k', ax=ax)
sns.countplot(Y_test, color='r', ax=ax, alpha=0.2)
ax.set_title("Error Analysis of model on tfidf feature on validation dataset")

```

    SGD score:  0.6590693257359924
    (1773,)
    (2553, 3)
    saved successfully





    Text(0.5, 1.0, 'Error Analysis of model on tfidf feature on validation dataset')




![png](output_82_2.png)



```python

```

**Build SVD Feature on TFIDF Feature**

1.     Run XGBoost Tree
2.     Support Vector Machine

We use Multiclass-Log-loss on these model, and also check **Top-3 Accuracy** performance.


```python
kuch_title1 = tfidf_feature(train4, test4, 'title', min_df=3, analyzer='word', 
                  token_pattern=r'\w{1,}', ngram=2, stopwords='english', 
                  n_component=75, decom_flag=True, which_method='svd', 
                  max_features=None, feat_col_name='svd_title1')

kuch_text1 = tfidf_feature(train4, test4, 'text', min_df=3, analyzer='word', 
                  token_pattern=r'\w{1,}', ngram=2, stopwords='english', 
                  n_component=150, decom_flag=True, which_method='svd', 
                  max_features=None, feat_col_name='svd_text1')


train_all = pd.concat([kuch_title1[0], kuch_text1[0]], axis=1)
test_all  = pd.concat([kuch_title1[1], kuch_text1[1]], axis=1)
print(train_all.shape, test_all.shape)

```

    ===============  done  ===============
    ===============  done  ===============
    (4210, 225) (1773, 225)



```python
def top_n_accuracy(truths, preds, n):
    best_n = np.argsort(preds, axis=1)[:,-n:]
#     ts = np.argmax(truths, axis=1)
    ts = truths
    success = 0
    for t, p in zip(ts, best_n):
        if t in p:
            success += 1
    return float(success)/preds.shape[0]


```


```python
def multiclass_logloss(actual, predicted, eps=1e-15):
    """ Multi class version of Logarithmic Loss metric.
    :param actual: Array containing the actual target classes
    :param predicted: Matrix with class predictions, one probability per class
    """
    # Convert 'actual' to a binary array if it's not already:
    if len(actual.shape) == 1:
        actual2 = np.zeros((actual.shape[0], predicted.shape[1]))
        for i, val in enumerate(actual):
            actual2[i, val] = 1
        actual = actual2

    clip = np.clip(predicted, eps, 1 - eps)
    rows = actual.shape[0]
    vsota = np.sum(actual * np.log(clip))
    return -1.0 / rows * vsota
```


```python
import xgboost as xgb
from sklearn.metrics import accuracy_score

X_train, X_test, Y_train, Y_test = train_test_split(
    train_all, train4['target'], 
    stratify  = train4['target'], 
    test_size = 0.25
)
print(X_train.shape, Y_train.shape)


clf = xgb.XGBClassifier(max_depth=4, n_estimators=200, colsample_bytree=0.8, 
                        subsample=0.8, nthread=4, learning_rate=0.1)
clf.fit(X_train, Y_train)
predictions = clf.predict_proba(X_test)

print ("logloss: %0.3f " % multiclass_logloss(Y_test, predictions))
score = accuracy_score(Y_test, np.argmax(predictions, axis=1))
print( "  auc = ", score )
print(top_n_accuracy(Y_test, predictions, 3))
print("="*60)
```

    logloss: 1.224 
      auc =  0.654320987654321
    0.8641975308641975
    ============================================================



```python
pred_xgb1 = clf.predict(test_all)
print(pred_xgb1.shape)

test4.reset_index(drop=True)
test4['topic'] = pred_xgb1
final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
final1 = final1[['save_text','save_title','target']]
final1.columns = sub.columns
print(final1.shape)

if not os.path.exists('submission'):
    os.makedirs('submission')
final1.to_csv('submission/tfidf_xgb1.csv',index=None)
print("saved successfully")

```

    (1773,)
    (2553, 3)
    saved successfully



```python
from sklearn.preprocessing import StandardScaler
scl = StandardScaler()
scl.fit(train_all)
train_all = scl.transform(train_all)

from sklearn.metrics import accuracy_score

X_train, X_test, Y_train, Y_test = train_test_split(
    train_all, train4['target'], 
    stratify  = train4['target'], 
    test_size = 0.25
)
print(X_train.shape, Y_train.shape)


clf = xgb.XGBClassifier(max_depth=5, n_estimators=200, colsample_bytree=0.7, 
                        subsample=0.7, nthread=8, learning_rate=0.1)
clf.fit(X_train, Y_train)
predictions = clf.predict_proba(X_test)

print ("logloss: %0.3f " % multiclass_logloss(Y_test, predictions))
score = accuracy_score(Y_test, np.argmax(predictions, axis=1))
print( "  auc = ", score )
print(top_n_accuracy(Y_test, predictions, 3))
print("="*60)

# pred_xgb2 = clf.predict(test_all)
# print(pred_xgb2.shape)

# test4.reset_index(drop=True)
# test4['topic'] = pred_xgb2
# final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
# final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
# final1 = final1[['save_text','save_title','target']]
# final1.columns = sub.columns
# print(final1.shape)

# if not os.path.exists('submission'):
#     os.makedirs('submission')
# final1.to_csv('submission/tfidf_xgb2.csv',index=None)
# print("saved successfully")

```

    logloss: 1.188 
      auc =  0.6676163342830009
    0.8660968660968661
    ============================================================



```python

```


```python

```

Deep Learning Based Model

1.   Mutliclass Classification (Tranformer Model)
2.   Multilabel Classification




```python
X_train, X_test, Y_train, Y_test = train_test_split(
    train4[['text','title']], train4['target'], 
    stratify  = train4['target'], 
    test_size = 0.25
)
```


```python
from keras.models import Sequential
from keras.layers.recurrent import LSTM, GRU
from keras.layers.core import Dense, Activation, Dropout
from keras.layers.embeddings import Embedding
from keras.layers.normalization import BatchNormalization
from keras.utils import np_utils
from keras.layers import GlobalMaxPooling1D, Conv1D, MaxPooling1D, Flatten, Bidirectional, SpatialDropout1D
from keras.preprocessing import sequence, text

```

    Using TensorFlow backend.



```python
from keras.models import Sequential
from keras.optimizers import Adam
from keras import Model

from keras.layers import Bidirectional, CuDNNLSTM, LSTM, CuDNNGRU, GRU, Embedding
from keras.layers import Dense, Input, Dropout, Activation, Conv1D, Flatten, Concatenate
from keras.layers import SpatialDropout1D, Dropout, GlobalMaxPooling1D, MaxPooling1D

from keras.regularizers import l2

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.callbacks import ModelCheckpoint, Callback, EarlyStopping,ReduceLROnPlateau

```


```python
from keras.engine.topology import Layer
from keras import backend as K
from keras import initializers, regularizers, constraints, optimizers, layers
class Attention(Layer):
    def __init__(self, step_dim, W_regularizer=None, b_regularizer=None, W_constraint=None, b_constraint=None, bias=True, **kwargs):
        self.supports_masking = True
        self.init = initializers.get('glorot_uniform')

        self.W_regularizer = regularizers.get(W_regularizer)
        self.b_regularizer = regularizers.get(b_regularizer)

        self.W_constraint = constraints.get(W_constraint)
        self.b_constraint = constraints.get(b_constraint)

        self.bias = bias
        self.step_dim = step_dim
        self.features_dim = 0
        super(Attention, self).__init__(**kwargs)

    def build(self, input_shape):
        assert len(input_shape) == 3

        self.W = self.add_weight((input_shape[-1],),
                                 initializer=self.init,
                                 name='{}_W'.format(self.name),
                                 regularizer=self.W_regularizer,
                                 constraint=self.W_constraint)
        self.features_dim = input_shape[-1]

        if self.bias:
            self.b = self.add_weight((input_shape[1],),
                                     initializer='zero',
                                     name='{}_b'.format(self.name),
                                     regularizer=self.b_regularizer,
                                     constraint=self.b_constraint)
        else:
            self.b = None

        self.built = True

    def compute_mask(self, input, input_mask=None):
        return None

    def call(self, x, mask=None):
        features_dim = self.features_dim
        step_dim = self.step_dim

        eij = K.reshape(K.dot(K.reshape(x, (-1, features_dim)),
                        K.reshape(self.W, (features_dim, 1))), (-1, step_dim))

        if self.bias: eij += self.b
        eij = K.tanh(eij)
        a = K.exp(eij)

        if mask is not None:
            a *= K.cast(mask, K.floatx())

        a /= K.cast(K.sum(a, axis=1, keepdims=True)+K.epsilon(), K.floatx())
        a = K.expand_dims(a)
        weighted_input = x * a
        return K.sum(weighted_input, axis=1)

    def compute_output_shape(self, input_shape):
        return input_shape[0],  self.features_dim

```


```python
# using keras tokenizer here
token = text.Tokenizer(num_words=None)
max_len = 128
max_len2 = 17

token.fit_on_texts(list(X_train['text']) + list(X_test['text']))
xtrain_seq = token.texts_to_sequences(X_train['text'])
xvalid_seq = token.texts_to_sequences(X_test['text'])
xtest_seq  = token.texts_to_sequences(test4['text'])

# zero pad the sequences
xtrain_pad = sequence.pad_sequences(xtrain_seq, maxlen=max_len)
xvalid_pad = sequence.pad_sequences(xvalid_seq, maxlen=max_len)
xtest_pad  = sequence.pad_sequences(xtest_seq, maxlen=max_len)

word_index = token.word_index

# create an embedding matrix for the words we have in the dataset
embedding_matrix = np.zeros((len(word_index) + 1, 300))
for word, i in tqdm(word_index.items()):
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix[i] = embedding_vector

        
# using keras tokenizer here
token1 = text.Tokenizer(num_words=None)

token1.fit_on_texts(list(X_train['title']) + list(X_test['title']))
xtrain_seq1 = token1.texts_to_sequences(X_train['title'])
xvalid_seq1 = token1.texts_to_sequences(X_test['title'])
xtest_seq1  = token1.texts_to_sequences(test4['title'])

# zero pad the sequences
xtrain_pad1 = sequence.pad_sequences(xtrain_seq1, maxlen=max_len2)
xvalid_pad1 = sequence.pad_sequences(xvalid_seq1, maxlen=max_len2)
xtest_pad1  = sequence.pad_sequences(xtest_seq1, maxlen=max_len2)

word_index1 = token1.word_index

# create an embedding matrix for the words we have in the dataset
embedding_matrix1 = np.zeros((len(word_index1) + 1, 300))
for word, i in tqdm(word_index1.items()):
    embedding_vector = embeddings_index.get(word)
    if embedding_vector is not None:
        embedding_matrix1[i] = embedding_vector

        
        
# ytrain_enc = np_utils.to_categorical(Y_train, num_classes=21)
# yvalid_enc = np_utils.to_categorical(Y_test, num_classes=21)

xtrain_pad.shape, xvalid_pad.shape, xtest_pad.shape, xtrain_pad1.shape, xvalid_pad1.shape, xtest_pad1.shape


```

    100%|██████████| 8031/8031 [00:00<00:00, 299787.79it/s]
    100%|██████████| 2367/2367 [00:00<00:00, 206097.39it/s]





    ((3157, 128), (1053, 128), (1773, 128), (3157, 17), (1053, 17), (1773, 17))




```python
ytrain_enc = np_utils.to_categorical(Y_train, num_classes=21)
yvalid_enc = np_utils.to_categorical(Y_test, num_classes=21)

```

**Transformer-Based (Attention Model) Architecture"


```python
try:
    del model_comp
    gc.collect()
except:
    print("no model previously")
    

# GRU with glove embeddings and two dense layers
max_len2 = 17
inp1 = Input(shape=(max_len,))
inp2 = Input(shape=(max_len2,))

x1 = Embedding(  len(word_index) + 1,
                 300,
                 weights=[embedding_matrix],
                 input_length=max_len,
                 trainable=False)(inp1)
x2 = Embedding(  len(word_index1) + 1,
                 300,
                 weights=[embedding_matrix1],
                 input_length=max_len2,
                 trainable=False)(inp2)

x1 = SpatialDropout1D(0.3)(x1)
x2 = SpatialDropout1D(0.3)(x2)

x1 = Bidirectional(LSTM(128, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)
# x1 = Bidirectional(LSTM(200, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)

x2 = Bidirectional(LSTM(64, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)
# x2 = Bidirectional(LSTM(100, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)

x1 = Attention(max_len)(x1)
x2 = Attention(max_len2)(x2)

x1 = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x1)
x1 = Dropout(0.7)(x1)

x2 = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x2)
x2 = Dropout(0.7)(x2)

x = Concatenate(axis=1)([x1,x2])
x = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x)
x = Dropout(0.7)(x)

x = Dense(21, kernel_regularizer=l2(1e-4))(x)
x = Activation('softmax')(x)

model_comp = Model(input=[inp1, inp2], output=x)
model_comp.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

model_comp.summary()
```

    WARNING: Logging before flag parsing goes to stderr.
    W0811 16:53:55.137963 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:74: The name tf.get_default_graph is deprecated. Please use tf.compat.v1.get_default_graph instead.
    
    W0811 16:53:55.183153 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:517: The name tf.placeholder is deprecated. Please use tf.compat.v1.placeholder instead.
    
    W0811 16:53:55.192569 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:4138: The name tf.random_uniform is deprecated. Please use tf.random.uniform instead.
    
    W0811 16:53:55.209286 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:174: The name tf.get_default_session is deprecated. Please use tf.compat.v1.get_default_session instead.
    
    W0811 16:53:55.210390 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:181: The name tf.ConfigProto is deprecated. Please use tf.compat.v1.ConfigProto instead.
    


    no model previously


    W0811 16:53:55.593811 139719481202560 deprecation.py:506] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:3445: calling dropout (from tensorflow.python.ops.nn_ops) with keep_prob is deprecated and will be removed in a future version.
    Instructions for updating:
    Please use `rate` instead of `keep_prob`. Rate should be set to `rate = 1 - keep_prob`.
    W0811 16:53:57.464386 139719481202560 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 16:53:57.504821 139719481202560 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 16:53:57.546210 139719481202560 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 16:53:57.581324 139719481202560 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/optimizers.py:790: The name tf.train.Optimizer is deprecated. Please use tf.compat.v1.train.Optimizer instead.
    


    __________________________________________________________________________________________________
    Layer (type)                    Output Shape         Param #     Connected to                     
    ==================================================================================================
    input_1 (InputLayer)            (None, 128)          0                                            
    __________________________________________________________________________________________________
    input_2 (InputLayer)            (None, 17)           0                                            
    __________________________________________________________________________________________________
    embedding_1 (Embedding)         (None, 128, 300)     2409600     input_1[0][0]                    
    __________________________________________________________________________________________________
    embedding_2 (Embedding)         (None, 17, 300)      710400      input_2[0][0]                    
    __________________________________________________________________________________________________
    spatial_dropout1d_1 (SpatialDro (None, 128, 300)     0           embedding_1[0][0]                
    __________________________________________________________________________________________________
    spatial_dropout1d_2 (SpatialDro (None, 17, 300)      0           embedding_2[0][0]                
    __________________________________________________________________________________________________
    bidirectional_1 (Bidirectional) (None, 128, 256)     439296      spatial_dropout1d_1[0][0]        
    __________________________________________________________________________________________________
    bidirectional_2 (Bidirectional) (None, 17, 128)      186880      spatial_dropout1d_2[0][0]        
    __________________________________________________________________________________________________
    attention_1 (Attention)         (None, 256)          384         bidirectional_1[0][0]            
    __________________________________________________________________________________________________
    attention_2 (Attention)         (None, 128)          145         bidirectional_2[0][0]            
    __________________________________________________________________________________________________
    dense_1 (Dense)                 (None, 756)          194292      attention_1[0][0]                
    __________________________________________________________________________________________________
    dense_2 (Dense)                 (None, 756)          97524       attention_2[0][0]                
    __________________________________________________________________________________________________
    dropout_1 (Dropout)             (None, 756)          0           dense_1[0][0]                    
    __________________________________________________________________________________________________
    dropout_2 (Dropout)             (None, 756)          0           dense_2[0][0]                    
    __________________________________________________________________________________________________
    concatenate_1 (Concatenate)     (None, 1512)         0           dropout_1[0][0]                  
                                                                     dropout_2[0][0]                  
    __________________________________________________________________________________________________
    dense_3 (Dense)                 (None, 756)          1143828     concatenate_1[0][0]              
    __________________________________________________________________________________________________
    dropout_3 (Dropout)             (None, 756)          0           dense_3[0][0]                    
    __________________________________________________________________________________________________
    dense_4 (Dense)                 (None, 21)           15897       dropout_3[0][0]                  
    __________________________________________________________________________________________________
    activation_1 (Activation)       (None, 21)           0           dense_4[0][0]                    
    ==================================================================================================
    Total params: 5,198,246
    Trainable params: 2,078,246
    Non-trainable params: 3,120,000
    __________________________________________________________________________________________________



```python
epochs = 50
batch_size = 256

reducelr = ReduceLROnPlateau(factor=np.sqrt(0.1), monitor='val_acc', patience=2)
modelcheck = ModelCheckpoint('atten_lstm_small.h5', monitor='val_acc', verbose=0, save_best_only=True, period=2)
earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=3, verbose=0, mode='auto')

model_comp.fit(
    x=[xtrain_pad, xtrain_pad1], 
    y=ytrain_enc, 
    batch_size=batch_size, 
    epochs=epochs, 
    verbose=1, 
    validation_data=([xvalid_pad, xvalid_pad1], yvalid_enc), 
    callbacks=[reducelr, modelcheck, earlystop]
)
```

    W0811 16:55:21.341273 139719481202560 deprecation.py:323] From /usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/math_grad.py:1250: add_dispatch_support.<locals>.wrapper (from tensorflow.python.ops.array_ops) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use tf.where in 2.0, which has the same broadcast rule as np.where


    Train on 3157 samples, validate on 1053 samples
    Epoch 1/50
    3157/3157 [==============================] - 48s 15ms/step - loss: 3.1377 - acc: 0.1223 - val_loss: 2.9079 - val_acc: 0.2146
    Epoch 2/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 2.9166 - acc: 0.1555 - val_loss: 2.7674 - val_acc: 0.2346
    Epoch 3/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.7738 - acc: 0.2239 - val_loss: 2.5779 - val_acc: 0.3067
    Epoch 4/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.5870 - acc: 0.2879 - val_loss: 2.3401 - val_acc: 0.3913
    Epoch 5/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.4070 - acc: 0.3339 - val_loss: 2.1919 - val_acc: 0.4141
    Epoch 6/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 2.2686 - acc: 0.3811 - val_loss: 2.0772 - val_acc: 0.4539
    Epoch 7/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.1612 - acc: 0.4153 - val_loss: 1.9933 - val_acc: 0.4900
    Epoch 8/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.0879 - acc: 0.4444 - val_loss: 1.9619 - val_acc: 0.4967
    Epoch 9/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 2.0295 - acc: 0.4697 - val_loss: 1.8852 - val_acc: 0.5195
    Epoch 10/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.9603 - acc: 0.4869 - val_loss: 1.8437 - val_acc: 0.5261
    Epoch 11/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.8988 - acc: 0.5024 - val_loss: 1.8068 - val_acc: 0.5385
    Epoch 12/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.8539 - acc: 0.5195 - val_loss: 1.7877 - val_acc: 0.5385
    Epoch 13/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.8291 - acc: 0.5325 - val_loss: 1.7570 - val_acc: 0.5565
    Epoch 14/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.7832 - acc: 0.5489 - val_loss: 1.7282 - val_acc: 0.5745
    Epoch 15/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.7635 - acc: 0.5512 - val_loss: 1.7085 - val_acc: 0.5793
    Epoch 16/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.7072 - acc: 0.5676 - val_loss: 1.6619 - val_acc: 0.5907
    Epoch 17/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.6592 - acc: 0.5746 - val_loss: 1.6532 - val_acc: 0.6002
    Epoch 18/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.6288 - acc: 0.5927 - val_loss: 1.6322 - val_acc: 0.6135
    Epoch 19/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.5982 - acc: 0.5987 - val_loss: 1.6064 - val_acc: 0.6116
    Epoch 20/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.5759 - acc: 0.6015 - val_loss: 1.5558 - val_acc: 0.6420
    Epoch 21/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.5358 - acc: 0.6294 - val_loss: 1.5271 - val_acc: 0.6591
    Epoch 22/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.4802 - acc: 0.6481 - val_loss: 1.5126 - val_acc: 0.6610
    Epoch 23/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.4531 - acc: 0.6513 - val_loss: 1.4994 - val_acc: 0.6629
    Epoch 24/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.4028 - acc: 0.6744 - val_loss: 1.4595 - val_acc: 0.6838
    Epoch 25/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.3520 - acc: 0.6801 - val_loss: 1.4511 - val_acc: 0.6800
    Epoch 26/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.3435 - acc: 0.6937 - val_loss: 1.4234 - val_acc: 0.6885
    Epoch 27/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.3049 - acc: 0.6918 - val_loss: 1.4037 - val_acc: 0.6971
    Epoch 28/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.2951 - acc: 0.7007 - val_loss: 1.4065 - val_acc: 0.6942
    Epoch 29/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.2352 - acc: 0.7263 - val_loss: 1.4129 - val_acc: 0.7009
    Epoch 30/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.1979 - acc: 0.7257 - val_loss: 1.3811 - val_acc: 0.7208
    Epoch 31/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.1805 - acc: 0.7374 - val_loss: 1.3581 - val_acc: 0.7198
    Epoch 32/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.1588 - acc: 0.7434 - val_loss: 1.3382 - val_acc: 0.7274
    Epoch 33/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.1293 - acc: 0.7422 - val_loss: 1.3760 - val_acc: 0.7246
    Epoch 34/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.1258 - acc: 0.7536 - val_loss: 1.3109 - val_acc: 0.7360
    Epoch 35/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 1.0801 - acc: 0.7672 - val_loss: 1.3274 - val_acc: 0.7369
    Epoch 36/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.0697 - acc: 0.7726 - val_loss: 1.3027 - val_acc: 0.7341
    Epoch 37/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.0485 - acc: 0.7707 - val_loss: 1.3173 - val_acc: 0.7445
    Epoch 38/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 1.0463 - acc: 0.7795 - val_loss: 1.3016 - val_acc: 0.7464
    Epoch 39/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 0.9948 - acc: 0.7925 - val_loss: 1.3072 - val_acc: 0.7550
    Epoch 40/50
    3157/3157 [==============================] - 41s 13ms/step - loss: 0.9950 - acc: 0.7919 - val_loss: 1.3212 - val_acc: 0.7502
    Epoch 41/50
    3157/3157 [==============================] - 42s 13ms/step - loss: 0.9673 - acc: 0.8058 - val_loss: 1.3194 - val_acc: 0.7607





    <keras.callbacks.History at 0x7f12914a1588>




```python
plt.plot(model_comp.history.history['acc'],c='k')
plt.plot(model_comp.history.history['val_acc'],c='r')
```




    [<matplotlib.lines.Line2D at 0x7f128e673a20>]




![png](output_103_1.png)



```python
pred11 = model_comp.predict([xtest_pad, xtest_pad1], batch_size=250, verbose=1)
pred111 = np.argmax(pred11, axis=1)
print(pred11.shape)

test4.reset_index(drop=True)
test4['topic'] = pred111
final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
final1 = final1[['save_text','save_title','target']]
final1.columns = sub.columns
print(final1.shape)
if not os.path.exists('submission'):
    os.makedirs('submission')
final1.to_csv('submission/deep_attn_lstm_small.csv',index=None)
print("saved successfully")

```

    1773/1773 [==============================] - 8s 4ms/step
    (1773, 21)
    (2553, 3)
    saved successfully



```python

```


```python
# try:
#     del model_comp
#     gc.collect()
# except:
#     print("no model previously")
    

# # GRU with glove embeddings and two dense layers
# max_len2 = 17
# inp1 = Input(shape=(max_len,))
# inp2 = Input(shape=(max_len2,))

# x1 = Embedding(  len(word_index) + 1,
#                  300,
#                  weights=[embedding_matrix],
#                  input_length=max_len,
#                  trainable=False)(inp1)
# x2 = Embedding(  len(word_index1) + 1,
#                  300,
#                  weights=[embedding_matrix1],
#                  input_length=max_len2,
#                  trainable=False)(inp2)

# x1 = SpatialDropout1D(0.3)(x1)
# x2 = SpatialDropout1D(0.3)(x2)

# x1 = Bidirectional(LSTM(200, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)
# x1 = Bidirectional(LSTM(200, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)

# x2 = Bidirectional(LSTM(100, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)
# x2 = Bidirectional(LSTM(100, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)

# x1 = Attention(max_len)(x1)
# x2 = Attention(max_len2)(x2)

# x1 = Dense(1024, activation='relu', kernel_regularizer=l2(1e-4))(x1)
# x1 = Dropout(0.8)(x1)

# x2 = Dense(1024, activation='relu', kernel_regularizer=l2(1e-4))(x2)
# x2 = Dropout(0.8)(x2)

# x = Concatenate(axis=1)([x1,x2])
# x = Dense(1024, activation='relu', kernel_regularizer=l2(1e-4))(x)
# x = Dropout(0.8)(x)

# x = Dense(21, kernel_regularizer=l2(1e-4))(x)
# x = Activation('softmax')(x)

# model_comp = Model(input=[inp1, inp2], output=x)
# model_comp.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# model_comp.summary()
```

    W0811 06:27:28.797589 140037554907008 nn_ops.py:4224] Large dropout rate: 0.8 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 06:27:28.841862 140037554907008 nn_ops.py:4224] Large dropout rate: 0.8 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.


    __________________________________________________________________________________________________
    Layer (type)                    Output Shape         Param #     Connected to                     
    ==================================================================================================
    input_3 (InputLayer)            (None, 128)          0                                            
    __________________________________________________________________________________________________
    input_4 (InputLayer)            (None, 17)           0                                            
    __________________________________________________________________________________________________
    embedding_3 (Embedding)         (None, 128, 300)     2409600     input_3[0][0]                    
    __________________________________________________________________________________________________
    embedding_4 (Embedding)         (None, 17, 300)      710400      input_4[0][0]                    
    __________________________________________________________________________________________________
    spatial_dropout1d_3 (SpatialDro (None, 128, 300)     0           embedding_3[0][0]                
    __________________________________________________________________________________________________
    spatial_dropout1d_4 (SpatialDro (None, 17, 300)      0           embedding_4[0][0]                
    __________________________________________________________________________________________________
    bidirectional_5 (Bidirectional) (None, 128, 400)     801600      spatial_dropout1d_3[0][0]        
    __________________________________________________________________________________________________
    bidirectional_7 (Bidirectional) (None, 17, 200)      320800      spatial_dropout1d_4[0][0]        
    __________________________________________________________________________________________________
    bidirectional_6 (Bidirectional) (None, 128, 400)     961600      bidirectional_5[0][0]            
    __________________________________________________________________________________________________
    bidirectional_8 (Bidirectional) (None, 17, 200)      240800      bidirectional_7[0][0]            
    __________________________________________________________________________________________________
    attention_3 (Attention)         (None, 400)          528         bidirectional_6[0][0]            
    __________________________________________________________________________________________________
    attention_4 (Attention)         (None, 200)          217         bidirectional_8[0][0]            
    __________________________________________________________________________________________________
    dense_5 (Dense)                 (None, 1024)         410624      attention_3[0][0]                
    __________________________________________________________________________________________________
    dense_6 (Dense)                 (None, 1024)         205824      attention_4[0][0]                
    __________________________________________________________________________________________________
    dropout_4 (Dropout)             (None, 1024)         0           dense_5[0][0]                    
    __________________________________________________________________________________________________
    dropout_5 (Dropout)             (None, 1024)         0           dense_6[0][0]                    
    __________________________________________________________________________________________________
    concatenate_2 (Concatenate)     (None, 2048)         0           dropout_4[0][0]                  
                                                                     dropout_5[0][0]                  
    __________________________________________________________________________________________________
    dense_7 (Dense)                 (None, 1024)         2098176     concatenate_2[0][0]              
    __________________________________________________________________________________________________
    dropout_6 (Dropout)             (None, 1024)         0           dense_7[0][0]                    
    __________________________________________________________________________________________________
    dense_8 (Dense)                 (None, 21)           21525       dropout_6[0][0]                  
    __________________________________________________________________________________________________
    activation_2 (Activation)       (None, 21)           0           dense_8[0][0]                    
    ==================================================================================================
    Total params: 8,181,694
    Trainable params: 5,061,694
    Non-trainable params: 3,120,000
    __________________________________________________________________________________________________



```python
# epochs = 70
# batch_size = 256

# reducelr = ReduceLROnPlateau(factor=np.sqrt(0.1), monitor='val_loss', patience=2)
# modelcheck = ModelCheckpoint('model_atten_lstm_comb.h5', monitor='val_loss', verbose=0, save_best_only=True, period=2)
# earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=3, verbose=0, mode='auto')

# model_comp.fit(
#     x=[xtrain_pad, xtrain_pad1], 
#     y=ytrain_enc, 
#     batch_size=batch_size, 
#     epochs=epochs, 
#     verbose=1, 
#     validation_data=([xvalid_pad, xvalid_pad1], yvalid_enc), 
#     callbacks=[reducelr, modelcheck, earlystop]
# )
```

    Train on 3157 samples, validate on 1053 samples
    Epoch 1/70
    3157/3157 [==============================] - 184s 58ms/step - loss: 3.4169 - acc: 0.1121 - val_loss: 3.1909 - val_acc: 0.1472
    Epoch 2/70
    3157/3157 [==============================] - 166s 52ms/step - loss: 3.1783 - acc: 0.1375 - val_loss: 3.0392 - val_acc: 0.1871
    Epoch 3/70
    3157/3157 [==============================] - 168s 53ms/step - loss: 3.0187 - acc: 0.1844 - val_loss: 2.8732 - val_acc: 0.2213
    Epoch 4/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 2.8616 - acc: 0.2354 - val_loss: 2.6935 - val_acc: 0.2868
    Epoch 5/70
    3157/3157 [==============================] - 169s 54ms/step - loss: 2.7108 - acc: 0.2838 - val_loss: 2.5858 - val_acc: 0.3162
    Epoch 6/70
    3157/3157 [==============================] - 168s 53ms/step - loss: 2.6068 - acc: 0.3187 - val_loss: 2.5011 - val_acc: 0.3485
    Epoch 7/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 2.5130 - acc: 0.3643 - val_loss: 2.4137 - val_acc: 0.3970
    Epoch 8/70
    3157/3157 [==============================] - 157s 50ms/step - loss: 2.4370 - acc: 0.3706 - val_loss: 2.3535 - val_acc: 0.4226
    Epoch 9/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 2.3361 - acc: 0.4232 - val_loss: 2.2953 - val_acc: 0.4482
    Epoch 10/70
    3157/3157 [==============================] - 159s 50ms/step - loss: 2.2640 - acc: 0.4393 - val_loss: 2.2306 - val_acc: 0.4596
    Epoch 11/70
    3157/3157 [==============================] - 164s 52ms/step - loss: 2.1880 - acc: 0.4609 - val_loss: 2.1822 - val_acc: 0.4938
    Epoch 12/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 2.1677 - acc: 0.4691 - val_loss: 2.1693 - val_acc: 0.4853
    Epoch 13/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 2.1199 - acc: 0.4862 - val_loss: 2.1434 - val_acc: 0.4720
    Epoch 14/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 2.0664 - acc: 0.5033 - val_loss: 2.1184 - val_acc: 0.4986
    Epoch 15/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 2.0438 - acc: 0.5008 - val_loss: 2.0823 - val_acc: 0.4995
    Epoch 16/70
    3157/3157 [==============================] - 161s 51ms/step - loss: 1.9971 - acc: 0.5223 - val_loss: 2.0456 - val_acc: 0.5138
    Epoch 17/70
    3157/3157 [==============================] - 161s 51ms/step - loss: 1.9689 - acc: 0.5264 - val_loss: 2.0395 - val_acc: 0.5223
    Epoch 18/70
    3157/3157 [==============================] - 161s 51ms/step - loss: 1.9533 - acc: 0.5318 - val_loss: 2.0836 - val_acc: 0.4986
    Epoch 19/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.9287 - acc: 0.5474 - val_loss: 2.0122 - val_acc: 0.5185
    Epoch 20/70
    3157/3157 [==============================] - 161s 51ms/step - loss: 1.8899 - acc: 0.5588 - val_loss: 1.9794 - val_acc: 0.5385
    Epoch 21/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 1.8467 - acc: 0.5569 - val_loss: 1.9782 - val_acc: 0.5337
    Epoch 22/70
    3157/3157 [==============================] - 156s 49ms/step - loss: 1.8197 - acc: 0.5727 - val_loss: 1.9815 - val_acc: 0.5337
    Epoch 23/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.7866 - acc: 0.5841 - val_loss: 1.9345 - val_acc: 0.5660
    Epoch 24/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 1.7408 - acc: 0.6006 - val_loss: 1.8973 - val_acc: 0.5897
    Epoch 25/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.7174 - acc: 0.6079 - val_loss: 1.8904 - val_acc: 0.5869
    Epoch 26/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.6821 - acc: 0.6262 - val_loss: 1.8002 - val_acc: 0.6201
    Epoch 27/70
    3157/3157 [==============================] - 157s 50ms/step - loss: 1.6400 - acc: 0.6424 - val_loss: 1.7623 - val_acc: 0.6258
    Epoch 28/70
    3157/3157 [==============================] - 158s 50ms/step - loss: 1.6536 - acc: 0.6408 - val_loss: 1.7596 - val_acc: 0.6486
    Epoch 29/70
    3157/3157 [==============================] - 159s 50ms/step - loss: 1.5643 - acc: 0.6756 - val_loss: 1.6947 - val_acc: 0.6458
    Epoch 30/70
    3157/3157 [==============================] - 157s 50ms/step - loss: 1.5166 - acc: 0.6769 - val_loss: 1.6789 - val_acc: 0.6781
    Epoch 31/70
    3157/3157 [==============================] - 160s 51ms/step - loss: 1.4856 - acc: 0.6965 - val_loss: 1.6616 - val_acc: 0.6705
    Epoch 32/70
    3157/3157 [==============================] - 160s 51ms/step - loss: 1.4324 - acc: 0.7099 - val_loss: 1.6384 - val_acc: 0.6866
    Epoch 33/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.4205 - acc: 0.7187 - val_loss: 1.6469 - val_acc: 0.6904
    Epoch 34/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.3948 - acc: 0.7289 - val_loss: 1.6047 - val_acc: 0.6952
    Epoch 35/70
    3157/3157 [==============================] - 163s 52ms/step - loss: 1.3612 - acc: 0.7304 - val_loss: 1.6000 - val_acc: 0.6952
    Epoch 36/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.3408 - acc: 0.7469 - val_loss: 1.6044 - val_acc: 0.7066
    Epoch 37/70
    3157/3157 [==============================] - 160s 51ms/step - loss: 1.3315 - acc: 0.7352 - val_loss: 1.6041 - val_acc: 0.7037
    Epoch 38/70
    3157/3157 [==============================] - 162s 51ms/step - loss: 1.2984 - acc: 0.7529 - val_loss: 1.5801 - val_acc: 0.7104
    Epoch 39/70
    3157/3157 [==============================] - 157s 50ms/step - loss: 1.2719 - acc: 0.7583 - val_loss: 1.6027 - val_acc: 0.7075
    Epoch 40/70
    3157/3157 [==============================] - 156s 49ms/step - loss: 1.2315 - acc: 0.7596 - val_loss: 1.5890 - val_acc: 0.7151
    Epoch 41/70
    3157/3157 [==============================] - 157s 50ms/step - loss: 1.2511 - acc: 0.7599 - val_loss: 1.5831 - val_acc: 0.7151





    <keras.callbacks.History at 0x7f5cad6690f0>




```python
# pred11 = model_comp.predict([xtest_pad, xtest_pad1], batch_size=500, verbose=1)
# pred111 = np.argmax(pred11, axis=1)
# print(pred11.shape)

# test4.reset_index(drop=True)
# test4['topic'] = pred111
# final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
# final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
# final1 = final1[['save_text','save_title','target']]
# final1.columns = sub.columns
# print(final1.shape)
# if not os.path.exists('submission'):
#     os.make_dirs('submission')
# final1.to_csv('submission/deep_att_lstm.csv',index=None)
# final1.head()
```

    1773/1773 [==============================] - 25s 14ms/step
    (1773, 21)
    (2553, 3)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Review Text</th>
      <th>Review Title</th>
      <th>topic</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>I use chia seed in my protein shakes. These ta...</td>
      <td>Bad tast</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>1</th>
      <td>I use chia seed in my protein shakes. These ta...</td>
      <td>Bad tast</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Don’t waste your money.</td>
      <td>No change. No results.</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>3</th>
      <td>I use the book 'Fortify Your Life' by Tieraona...</td>
      <td>Good Vegan Choice, Poor Non Vegan Choice</td>
      <td>Ingredients</td>
    </tr>
    <tr>
      <th>4</th>
      <td>I use the book 'Fortify Your Life' by Tieraona...</td>
      <td>Good Vegan Choice, Poor Non Vegan Choice</td>
      <td>Ingredients</td>
    </tr>
  </tbody>
</table>
</div>




```python
# try:
#     del model_comp1
#     gc.collect()
# except:
#     print("no model previously")
    

# # GRU with glove embeddings and two dense layers
# max_len2 = 17
# inp1 = Input(shape=(max_len,))
# inp2 = Input(shape=(max_len2,))

# x1 = Embedding(  len(word_index) + 1,
#                  300,
#                  weights=[embedding_matrix],
#                  input_length=max_len,
#                  trainable=False)(inp1)
# x2 = Embedding(  len(word_index1) + 1,
#                  300,
#                  weights=[embedding_matrix1],
#                  input_length=max_len2,
#                  trainable=False)(inp2)

# x1 = SpatialDropout1D(0.3)(x1)
# x2 = SpatialDropout1D(0.3)(x2)

# x1 = Bidirectional(LSTM(120, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)
# x1 = Bidirectional(LSTM(120, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x1)

# x2 = Bidirectional(LSTM(70, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)
# x2 = Bidirectional(LSTM(70, dropout=0.3, recurrent_dropout=0.3, return_sequences=True, kernel_regularizer=l2(1e-4)))(x2)

# x1 = Attention(max_len)(x1)
# x2 = Attention(max_len2)(x2)

# x1 = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x1)
# x1 = Dropout(0.7)(x1)

# x2 = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x2)
# x2 = Dropout(0.7)(x2)

# x = Concatenate(axis=1)([x1,x2])
# x = Dense(756, activation='relu', kernel_regularizer=l2(1e-4))(x)
# x = Dropout(0.7)(x)

# x = Dense(21, kernel_regularizer=l2(1e-4))(x)
# x = Activation('sigmoid')(x)

# model_comp1 = Model(input=[inp1, inp2], output=x)
# model_comp1.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

# model_comp1.summary()
```

    WARNING: Logging before flag parsing goes to stderr.
    W0811 10:14:19.023206 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:74: The name tf.get_default_graph is deprecated. Please use tf.compat.v1.get_default_graph instead.
    
    W0811 10:14:19.070110 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:517: The name tf.placeholder is deprecated. Please use tf.compat.v1.placeholder instead.
    
    W0811 10:14:19.083018 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:4138: The name tf.random_uniform is deprecated. Please use tf.random.uniform instead.
    
    W0811 10:14:19.100563 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:174: The name tf.get_default_session is deprecated. Please use tf.compat.v1.get_default_session instead.
    
    W0811 10:14:19.101979 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:181: The name tf.ConfigProto is deprecated. Please use tf.compat.v1.ConfigProto instead.
    


    no model previously


    W0811 10:14:19.576651 139968440121216 deprecation.py:506] From /usr/local/lib/python3.6/dist-packages/keras/backend/tensorflow_backend.py:3445: calling dropout (from tensorflow.python.ops.nn_ops) with keep_prob is deprecated and will be removed in a future version.
    Instructions for updating:
    Please use `rate` instead of `keep_prob`. Rate should be set to `rate = 1 - keep_prob`.
    W0811 10:14:23.232602 139968440121216 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 10:14:23.272989 139968440121216 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 10:14:23.313766 139968440121216 nn_ops.py:4224] Large dropout rate: 0.7 (>0.5). In TensorFlow 2.x, dropout() uses dropout rate instead of keep_prob. Please ensure that this is intended.
    W0811 10:14:23.349565 139968440121216 deprecation_wrapper.py:119] From /usr/local/lib/python3.6/dist-packages/keras/optimizers.py:790: The name tf.train.Optimizer is deprecated. Please use tf.compat.v1.train.Optimizer instead.
    
    W0811 10:14:23.376734 139968440121216 deprecation.py:323] From /usr/local/lib/python3.6/dist-packages/tensorflow/python/ops/nn_impl.py:180: add_dispatch_support.<locals>.wrapper (from tensorflow.python.ops.array_ops) is deprecated and will be removed in a future version.
    Instructions for updating:
    Use tf.where in 2.0, which has the same broadcast rule as np.where


    __________________________________________________________________________________________________
    Layer (type)                    Output Shape         Param #     Connected to                     
    ==================================================================================================
    input_1 (InputLayer)            (None, 128)          0                                            
    __________________________________________________________________________________________________
    input_2 (InputLayer)            (None, 17)           0                                            
    __________________________________________________________________________________________________
    embedding_1 (Embedding)         (None, 128, 300)     2409600     input_1[0][0]                    
    __________________________________________________________________________________________________
    embedding_2 (Embedding)         (None, 17, 300)      710400      input_2[0][0]                    
    __________________________________________________________________________________________________
    spatial_dropout1d_1 (SpatialDro (None, 128, 300)     0           embedding_1[0][0]                
    __________________________________________________________________________________________________
    spatial_dropout1d_2 (SpatialDro (None, 17, 300)      0           embedding_2[0][0]                
    __________________________________________________________________________________________________
    bidirectional_1 (Bidirectional) (None, 128, 240)     404160      spatial_dropout1d_1[0][0]        
    __________________________________________________________________________________________________
    bidirectional_3 (Bidirectional) (None, 17, 140)      207760      spatial_dropout1d_2[0][0]        
    __________________________________________________________________________________________________
    bidirectional_2 (Bidirectional) (None, 128, 240)     346560      bidirectional_1[0][0]            
    __________________________________________________________________________________________________
    bidirectional_4 (Bidirectional) (None, 17, 140)      118160      bidirectional_3[0][0]            
    __________________________________________________________________________________________________
    attention_1 (Attention)         (None, 240)          368         bidirectional_2[0][0]            
    __________________________________________________________________________________________________
    attention_2 (Attention)         (None, 140)          157         bidirectional_4[0][0]            
    __________________________________________________________________________________________________
    dense_1 (Dense)                 (None, 756)          182196      attention_1[0][0]                
    __________________________________________________________________________________________________
    dense_2 (Dense)                 (None, 756)          106596      attention_2[0][0]                
    __________________________________________________________________________________________________
    dropout_1 (Dropout)             (None, 756)          0           dense_1[0][0]                    
    __________________________________________________________________________________________________
    dropout_2 (Dropout)             (None, 756)          0           dense_2[0][0]                    
    __________________________________________________________________________________________________
    concatenate_1 (Concatenate)     (None, 1512)         0           dropout_1[0][0]                  
                                                                     dropout_2[0][0]                  
    __________________________________________________________________________________________________
    dense_3 (Dense)                 (None, 756)          1143828     concatenate_1[0][0]              
    __________________________________________________________________________________________________
    dropout_3 (Dropout)             (None, 756)          0           dense_3[0][0]                    
    __________________________________________________________________________________________________
    dense_4 (Dense)                 (None, 21)           15897       dropout_3[0][0]                  
    __________________________________________________________________________________________________
    activation_1 (Activation)       (None, 21)           0           dense_4[0][0]                    
    ==================================================================================================
    Total params: 5,645,682
    Trainable params: 2,525,682
    Non-trainable params: 3,120,000
    __________________________________________________________________________________________________



```python
# epochs = 70
# batch_size = 128

# reducelr = ReduceLROnPlateau(factor=np.sqrt(0.1), monitor='val_loss', patience=2)
# modelcheck = ModelCheckpoint('model_atten_lstm_comb1.h5', monitor='val_loss', verbose=0, save_best_only=True, period=2)
# earlystop = EarlyStopping(monitor='val_loss', min_delta=0, patience=3, verbose=0, mode='auto')

# model_comp1.fit(
#     x=[xtrain_pad, xtrain_pad1], 
#     y=Y_train.values, 
#     batch_size=batch_size, 
#     epochs=epochs, 
#     verbose=1, 
#     validation_data=([xvalid_pad, xvalid_pad1], Y_test.values), 
#     callbacks=[reducelr, modelcheck, earlystop]
# )
```

    Train on 3157 samples, validate on 1053 samples
    Epoch 1/70
    3157/3157 [==============================] - 103s 33ms/step - loss: 0.6965 - acc: 0.8914 - val_loss: 0.4887 - val_acc: 0.9324
    Epoch 2/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.4425 - acc: 0.9313 - val_loss: 0.3813 - val_acc: 0.9324
    Epoch 3/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.3598 - acc: 0.9336 - val_loss: 0.3201 - val_acc: 0.9361
    Epoch 4/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.3107 - acc: 0.9361 - val_loss: 0.2868 - val_acc: 0.9372
    Epoch 5/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2844 - acc: 0.9365 - val_loss: 0.2657 - val_acc: 0.9377
    Epoch 6/70
    3157/3157 [==============================] - 93s 29ms/step - loss: 0.2654 - acc: 0.9366 - val_loss: 0.2505 - val_acc: 0.9380
    Epoch 7/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2522 - acc: 0.9369 - val_loss: 0.2387 - val_acc: 0.9389
    Epoch 8/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2423 - acc: 0.9375 - val_loss: 0.2302 - val_acc: 0.9395
    Epoch 9/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2335 - acc: 0.9389 - val_loss: 0.2237 - val_acc: 0.9401
    Epoch 10/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2274 - acc: 0.9392 - val_loss: 0.2172 - val_acc: 0.9416
    Epoch 11/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2200 - acc: 0.9403 - val_loss: 0.2126 - val_acc: 0.9432
    Epoch 12/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.2154 - acc: 0.9420 - val_loss: 0.2060 - val_acc: 0.9447
    Epoch 13/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2108 - acc: 0.9430 - val_loss: 0.2031 - val_acc: 0.9454
    Epoch 14/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.2078 - acc: 0.9438 - val_loss: 0.1990 - val_acc: 0.9472
    Epoch 15/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.2050 - acc: 0.9441 - val_loss: 0.1971 - val_acc: 0.9473
    Epoch 16/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.2036 - acc: 0.9447 - val_loss: 0.1949 - val_acc: 0.9474
    Epoch 17/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1998 - acc: 0.9456 - val_loss: 0.1925 - val_acc: 0.9480
    Epoch 18/70
    3157/3157 [==============================] - 108s 34ms/step - loss: 0.1971 - acc: 0.9455 - val_loss: 0.1895 - val_acc: 0.9487
    Epoch 19/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1944 - acc: 0.9462 - val_loss: 0.1887 - val_acc: 0.9487
    Epoch 20/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1934 - acc: 0.9466 - val_loss: 0.1872 - val_acc: 0.9487
    Epoch 21/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1922 - acc: 0.9463 - val_loss: 0.1881 - val_acc: 0.9481
    Epoch 22/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1895 - acc: 0.9478 - val_loss: 0.1857 - val_acc: 0.9474
    Epoch 23/70
    3157/3157 [==============================] - 100s 32ms/step - loss: 0.1901 - acc: 0.9468 - val_loss: 0.1878 - val_acc: 0.9485
    Epoch 24/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1894 - acc: 0.9483 - val_loss: 0.1829 - val_acc: 0.9502
    Epoch 25/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1870 - acc: 0.9483 - val_loss: 0.1826 - val_acc: 0.9499
    Epoch 26/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1852 - acc: 0.9487 - val_loss: 0.1812 - val_acc: 0.9507
    Epoch 27/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1826 - acc: 0.9497 - val_loss: 0.1819 - val_acc: 0.9498
    Epoch 28/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1826 - acc: 0.9493 - val_loss: 0.1793 - val_acc: 0.9511
    Epoch 29/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1806 - acc: 0.9497 - val_loss: 0.1789 - val_acc: 0.9502
    Epoch 30/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.1790 - acc: 0.9499 - val_loss: 0.1760 - val_acc: 0.9514
    Epoch 31/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1776 - acc: 0.9507 - val_loss: 0.1747 - val_acc: 0.9516
    Epoch 32/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1770 - acc: 0.9501 - val_loss: 0.1733 - val_acc: 0.9524
    Epoch 33/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1759 - acc: 0.9511 - val_loss: 0.1717 - val_acc: 0.9540
    Epoch 34/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.1750 - acc: 0.9520 - val_loss: 0.1705 - val_acc: 0.9542
    Epoch 35/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1728 - acc: 0.9533 - val_loss: 0.1723 - val_acc: 0.9541
    Epoch 36/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1731 - acc: 0.9533 - val_loss: 0.1702 - val_acc: 0.9553
    Epoch 37/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1720 - acc: 0.9541 - val_loss: 0.1676 - val_acc: 0.9561
    Epoch 38/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1709 - acc: 0.9552 - val_loss: 0.1683 - val_acc: 0.9574
    Epoch 39/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1685 - acc: 0.9560 - val_loss: 0.1665 - val_acc: 0.9565
    Epoch 40/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1692 - acc: 0.9552 - val_loss: 0.1644 - val_acc: 0.9579
    Epoch 41/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1669 - acc: 0.9568 - val_loss: 0.1631 - val_acc: 0.9584
    Epoch 42/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1672 - acc: 0.9570 - val_loss: 0.1641 - val_acc: 0.9587
    Epoch 43/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1653 - acc: 0.9575 - val_loss: 0.1626 - val_acc: 0.9593
    Epoch 44/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1654 - acc: 0.9578 - val_loss: 0.1615 - val_acc: 0.9597
    Epoch 45/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1641 - acc: 0.9583 - val_loss: 0.1624 - val_acc: 0.9602
    Epoch 46/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1651 - acc: 0.9581 - val_loss: 0.1619 - val_acc: 0.9596
    Epoch 47/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1608 - acc: 0.9595 - val_loss: 0.1595 - val_acc: 0.9605
    Epoch 48/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1581 - acc: 0.9598 - val_loss: 0.1577 - val_acc: 0.9607
    Epoch 49/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1551 - acc: 0.9601 - val_loss: 0.1569 - val_acc: 0.9607
    Epoch 50/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1561 - acc: 0.9602 - val_loss: 0.1551 - val_acc: 0.9609
    Epoch 51/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1530 - acc: 0.9609 - val_loss: 0.1551 - val_acc: 0.9606
    Epoch 52/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1525 - acc: 0.9607 - val_loss: 0.1553 - val_acc: 0.9607
    Epoch 53/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1527 - acc: 0.9607 - val_loss: 0.1540 - val_acc: 0.9611
    Epoch 54/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.1523 - acc: 0.9604 - val_loss: 0.1537 - val_acc: 0.9610
    Epoch 55/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1503 - acc: 0.9610 - val_loss: 0.1537 - val_acc: 0.9607
    Epoch 56/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1504 - acc: 0.9609 - val_loss: 0.1531 - val_acc: 0.9611
    Epoch 57/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1503 - acc: 0.9610 - val_loss: 0.1526 - val_acc: 0.9606
    Epoch 58/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1501 - acc: 0.9609 - val_loss: 0.1523 - val_acc: 0.9612
    Epoch 59/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1493 - acc: 0.9610 - val_loss: 0.1518 - val_acc: 0.9608
    Epoch 60/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1485 - acc: 0.9608 - val_loss: 0.1517 - val_acc: 0.9610
    Epoch 61/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1486 - acc: 0.9611 - val_loss: 0.1517 - val_acc: 0.9610
    Epoch 62/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1474 - acc: 0.9615 - val_loss: 0.1511 - val_acc: 0.9612
    Epoch 63/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.1496 - acc: 0.9610 - val_loss: 0.1508 - val_acc: 0.9611
    Epoch 64/70
    3157/3157 [==============================] - 92s 29ms/step - loss: 0.1489 - acc: 0.9611 - val_loss: 0.1507 - val_acc: 0.9612
    Epoch 65/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1485 - acc: 0.9610 - val_loss: 0.1505 - val_acc: 0.9612
    Epoch 66/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1466 - acc: 0.9615 - val_loss: 0.1504 - val_acc: 0.9613
    Epoch 67/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1460 - acc: 0.9616 - val_loss: 0.1506 - val_acc: 0.9612
    Epoch 68/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1467 - acc: 0.9612 - val_loss: 0.1504 - val_acc: 0.9613
    Epoch 69/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1471 - acc: 0.9612 - val_loss: 0.1501 - val_acc: 0.9614
    Epoch 70/70
    3157/3157 [==============================] - 91s 29ms/step - loss: 0.1473 - acc: 0.9608 - val_loss: 0.1499 - val_acc: 0.9611





    <keras.callbacks.History at 0x7f4ca4c43e10>




```python

```


```python
# plt.plot(model_comp1.history.history['acc'],c='k')
# plt.plot(model_comp1.history.history['val_acc'],c='r')
```




    [<matplotlib.lines.Line2D at 0x7f4c960e7b00>]




![png](output_112_1.png)



```python

```


```python
# pred11 = model_comp1.predict([xtest_pad, xtest_pad1], batch_size=250, verbose=1)
# pred111 = np.argmax(pred11, axis=1)
# print(pred11.shape)

# test4.reset_index(drop=True)
# test4['topic'] = pred111
# final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
# final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
# final1 = final1[['save_text','save_title','target']]
# final1.columns = sub.columns
# print(final1.shape)
# final1.to_csv('deep_att_lstm_multilabel.csv',index=None)
# final1.head()
```

    (1773, 21)
    (2553, 3)





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Review Text</th>
      <th>Review Title</th>
      <th>topic</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>I use chia seed in my protein shakes. These ta...</td>
      <td>Bad tast</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>1</th>
      <td>I use chia seed in my protein shakes. These ta...</td>
      <td>Bad tast</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Don’t waste your money.</td>
      <td>No change. No results.</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>3</th>
      <td>I use the book 'Fortify Your Life' by Tieraona...</td>
      <td>Good Vegan Choice, Poor Non Vegan Choice</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>4</th>
      <td>I use the book 'Fortify Your Life' by Tieraona...</td>
      <td>Good Vegan Choice, Poor Non Vegan Choice</td>
      <td>Allergic</td>
    </tr>
  </tbody>
</table>
</div>




```python

```


```python
# test['topic'] = 'null'
# gp = test.groupby(['text','title']).agg({
#         "topic": lambda x: " ".join(x.values)
#     })
# test11 = pd.DataFrame(gp.reset_index())
# test11.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>title</th>
      <th>topic</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>"Stir for 30 seconds until product dissolves."...</td>
      <td>Does Not Dissolve</td>
      <td>null</td>
    </tr>
    <tr>
      <th>1</th>
      <td>"X Brand" has failed to deliver what they offe...</td>
      <td>The 3-pack does not come with 3, only 1.</td>
      <td>null null</td>
    </tr>
    <tr>
      <th>2</th>
      <td>"X Brand" is screwing products. They sent hydr...</td>
      <td>Screwed up</td>
      <td>null null null</td>
    </tr>
    <tr>
      <th>3</th>
      <td>"X Brand" needs to make sure the top is sealed...</td>
      <td>Shipping Issues</td>
      <td>null</td>
    </tr>
    <tr>
      <th>4</th>
      <td>*I bought this when I thought I ran out.  I re...</td>
      <td>Too expensive for the strength.</td>
      <td>null</td>
    </tr>
  </tbody>
</table>
</div>




```python
# test_topics_len = test2['topic'].apply(lambda x: len(x.split(" ")))
# pred111 = []
# for row, len_ in zip(np.argsort(pred11), test_topics_len):
#     pred111.append(row[-len_:])
```


```python
# pred112 = [list(row) for row in pred111]
# test4['target'] = pred112
# test4.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>text</th>
      <th>title</th>
      <th>topic</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td></td>
      <td>the sellers did not ship timely and shipment g...</td>
      <td>null</td>
      <td>[15]</td>
    </tr>
    <tr>
      <th>1</th>
      <td>absolutely despised these vitamins wanted like...</td>
      <td>nope nope nope</td>
      <td>null</td>
      <td>[14, 1]</td>
    </tr>
    <tr>
      <th>2</th>
      <td>absolutely disgusted the delivery was delivere...</td>
      <td>delivery sucked</td>
      <td>null</td>
      <td>[12, 15]</td>
    </tr>
    <tr>
      <th>3</th>
      <td>absolutely terrible</td>
      <td>gross</td>
      <td>null</td>
      <td>[1]</td>
    </tr>
    <tr>
      <th>4</th>
      <td>accidentally ordered the one made with sugar a...</td>
      <td>sugarfree tastes better</td>
      <td>null</td>
      <td>[1]</td>
    </tr>
  </tbody>
</table>
</div>




```python
# texts = []
# titles = []
# topics = []
# count = 0
# for row in test4.values:
#     for target in row[-1]:
#         count += 1
#         chut = test11[(test11.text == row[0]) & (test11.title == row[1])].values
# #         , chut['save_title']
#         texts.append(chut[0][2])
# #         texts.append(chut['save_text'])
#         titles.append(chut[0][3])
#         topics.append(cl_map_inv[target])
        
# len(texts), count
```




    (2553, 2553)




```python
# final_sub = pd.DataFrame(data=[texts, titles, topics]).T
# final_sub.columns = sub.columns
# final_sub.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Review Text</th>
      <th>Review Title</th>
      <th>topic</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>The sellers didn’t ship timely and shipment go...</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Absolutely despised these vitamins. I wanted t...</td>
      <td>Nope nope nope</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Absolutely despised these vitamins. I wanted t...</td>
      <td>Nope nope nope</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Absolutely disgusted by the delivery! It was d...</td>
      <td>Delivery sucked</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Absolutely disgusted by the delivery! It was d...</td>
      <td>Delivery sucked</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>5</th>
      <td>It’s absolutely terrible</td>
      <td>Gross</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Accidentally ordered the one made with sugar. ...</td>
      <td>Sugarfree Tastes Better</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>7</th>
      <td>After 1 hour of taking this I had the worst tu...</td>
      <td>TUNNEL VISION and I felt like my head was in a...</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>8</th>
      <td>After 3 months of being stored at the proper t...</td>
      <td>Discolored</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>9</th>
      <td>After 3 months of being stored at the proper t...</td>
      <td>Discolored</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>10</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>11</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Customer Service</td>
    </tr>
    <tr>
      <th>12</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Color and texture</td>
    </tr>
    <tr>
      <th>13</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Texture</td>
    </tr>
    <tr>
      <th>14</th>
      <td>After taking it for 5 successive days I've ver...</td>
      <td>Terrible side effects</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>15</th>
      <td>After taking this since February, this product...</td>
      <td>Bad stomach pains &amp; can't return, &amp;upset</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>16</th>
      <td>After taking this since February, this product...</td>
      <td>Bad stomach pains &amp; can't return, &amp;upset</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>17</th>
      <td>After 2nd use, I woke in middle of the night w...</td>
      <td>Beware of stomach cramps</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>18</th>
      <td>After 2nd use, I woke in middle of the night w...</td>
      <td>Beware of stomach cramps</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>19</th>
      <td>After using a bottle of this product I cannot ...</td>
      <td>Did nothing for me.</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>20</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>21</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>22</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>23</th>
      <td>All I taste is chemicals and alcohol (and yes,...</td>
      <td>Bitter. Chemical-y. Etc...</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>24</th>
      <td>All I taste is chemicals and alcohol (and yes,...</td>
      <td>Bitter. Chemical-y. Etc...</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>25</th>
      <td>All I taste is nasty &amp; I have tried several br...</td>
      <td>Tastes Awful</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>26</th>
      <td>All the bags in one of the rolls was miss cut ...</td>
      <td>Poorly cut bags.</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Allergic reaction full body rash had to throw ...</td>
      <td>Allergic r xn</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>28</th>
      <td>I am allergic to these and get a rash when I t...</td>
      <td>Have to buy a better quality Vitamin D3, waste...</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Almost expired. Very terrible !!!!&lt;br /&gt;They d...</td>
      <td>They delivered the almost expired stuff. Very ...</td>
      <td>Expiry</td>
    </tr>
    <tr>
      <th>30</th>
      <td>I am almost finished with the first bottle. So...</td>
      <td>Hoped for more energy</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>31</th>
      <td>I'm almost positive the lengthy post of how gr...</td>
      <td>I wouldn't trust this brand if I were you.</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Also this product is not time released which i...</td>
      <td>tastes awful</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Although it shows like it was delivered to me,...</td>
      <td>Never received</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Although the bottle seemed to be ok the oil on...</td>
      <td>Cypress Essential Oil</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Although I wasn’t expecting these to be delici...</td>
      <td>Not palatable enough</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>36</th>
      <td>I alway pull 2 or 3 tissues they get stuck tog...</td>
      <td>Perfect till they run out too fast get stuck t...</td>
      <td>Texture</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Always buy this brand but for some reason whet...</td>
      <td>Bad mix</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Always by Now essentials oils at store. 1st ti...</td>
      <td>Delivery timing not what expected</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>39</th>
      <td>I ALWAYS order this brand of wipes for my baby...</td>
      <td>Received the WRONG wipes.</td>
      <td>Wrong Product received</td>
    </tr>
    <tr>
      <th>40</th>
      <td>My American Express was charged but I never re...</td>
      <td>Never received the product.</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>41</th>
      <td>and never had an issue, so I won't stop buying...</td>
      <td>I've bought quite a few things from NOW</td>
      <td>Too big to swallow</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Apparently had a rough trip one of two bottles...</td>
      <td>Shipping FRAGILE items beware</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Apparently, I missed the part of the descripti...</td>
      <td>Gross flavor</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Apparently, I missed the part of the descripti...</td>
      <td>Gross flavor</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>45</th>
      <td>We are a fan of this brand and it's effect on ...</td>
      <td>Love this brand, but this flavor is just too s...</td>
      <td>Too Sweet</td>
    </tr>
    <tr>
      <th>46</th>
      <td>We are a fan of this brand and it's effect on ...</td>
      <td>Love this brand, but this flavor is just too s...</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>47</th>
      <td>We are huge Garden Of Life fans. This was a ma...</td>
      <td>Our 8-year old with all of her teeth can’t che...</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>48</th>
      <td>We are huge Garden Of Life fans. This was a ma...</td>
      <td>Our 8-year old with all of her teeth can’t che...</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Arrived COMPLETELY all melted together. Useless</td>
      <td>Melted and useless</td>
      <td>Not Effective</td>
    </tr>
  </tbody>
</table>
</div>




```python
# test11 = test1.drop('topic', axis=1)
# test11 =test11.drop_duplicates()
# print(test11.shape)
```

    (1776, 4)



```python
# final_sub.to_csv('sub_multilabel.csv', index=None)
```


```python
# final_sub.head(25)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Review Text</th>
      <th>Review Title</th>
      <th>topic</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>The sellers didn’t ship timely and shipment go...</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Absolutely despised these vitamins. I wanted t...</td>
      <td>Nope nope nope</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Absolutely despised these vitamins. I wanted t...</td>
      <td>Nope nope nope</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Absolutely disgusted by the delivery! It was d...</td>
      <td>Delivery sucked</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Absolutely disgusted by the delivery! It was d...</td>
      <td>Delivery sucked</td>
      <td>Shipment and delivery</td>
    </tr>
    <tr>
      <th>5</th>
      <td>It’s absolutely terrible</td>
      <td>Gross</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Accidentally ordered the one made with sugar. ...</td>
      <td>Sugarfree Tastes Better</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>7</th>
      <td>After 1 hour of taking this I had the worst tu...</td>
      <td>TUNNEL VISION and I felt like my head was in a...</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>8</th>
      <td>After 3 months of being stored at the proper t...</td>
      <td>Discolored</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>9</th>
      <td>After 3 months of being stored at the proper t...</td>
      <td>Discolored</td>
      <td>Packaging</td>
    </tr>
    <tr>
      <th>10</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>11</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Customer Service</td>
    </tr>
    <tr>
      <th>12</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Color and texture</td>
    </tr>
    <tr>
      <th>13</th>
      <td>So after much trepidation, I bought this. Bott...</td>
      <td>BE AWARE! Fake? Scam?</td>
      <td>Texture</td>
    </tr>
    <tr>
      <th>14</th>
      <td>After taking it for 5 successive days I've ver...</td>
      <td>Terrible side effects</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>15</th>
      <td>After taking this since February, this product...</td>
      <td>Bad stomach pains &amp; can't return, &amp;upset</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>16</th>
      <td>After taking this since February, this product...</td>
      <td>Bad stomach pains &amp; can't return, &amp;upset</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>17</th>
      <td>After 2nd use, I woke in middle of the night w...</td>
      <td>Beware of stomach cramps</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>18</th>
      <td>After 2nd use, I woke in middle of the night w...</td>
      <td>Beware of stomach cramps</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>19</th>
      <td>After using a bottle of this product I cannot ...</td>
      <td>Did nothing for me.</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>20</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Not Effective</td>
    </tr>
    <tr>
      <th>21</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Quality/Contaminated</td>
    </tr>
    <tr>
      <th>22</th>
      <td>After YEARS of not being able to get a good ni...</td>
      <td>:(</td>
      <td>Allergic</td>
    </tr>
    <tr>
      <th>23</th>
      <td>All I taste is chemicals and alcohol (and yes,...</td>
      <td>Bitter. Chemical-y. Etc...</td>
      <td>Bad Taste/Flavor</td>
    </tr>
    <tr>
      <th>24</th>
      <td>All I taste is chemicals and alcohol (and yes,...</td>
      <td>Bitter. Chemical-y. Etc...</td>
      <td>Allergic</td>
    </tr>
  </tbody>
</table>
</div>




```python
# # pred11 = model_comp.predict([xtest_pad, xtest_pad1], batch_size=250, verbose=1)
# pred111 = np.argmax(pred11, axis=1)
# print(pred11.shape)

# test4.reset_index(drop=True)
# test4['topic'] = pred111
# final1 = pd.merge(test1[['text','title','save_text','save_title']], test4, how='left', on=['text','title'])
# final1['target'] = final1['topic'].apply(lambda x: cl_map_inv[x])
# final1 = final1[['save_text','save_title','target']]
# final1.columns = sub.columns
# print(final1.shape)
# final1.to_csv('submission/deep_att_lstm.csv',index=None)
# final1.head()
```


```python
# fig, ax = plt.subplots(7,3,figsize=(14,35))
# axes = ax.flatten()
# topics = list(train4.topic.unique())
# for ax,topic in zip(axes, topics):
#     sns.scatterplot(x='x',y='y',hue='target', c='k', 
#                     data=mapping2[mapping2.topic == topic], 
#                     ax=ax, legend=False)
#     ax.set_title(topic)

# # plt.legend(loc='best')
```


![png](output_125_0.png)



```python
# fig, ax = plt.subplots(1,1,figsize=(15,10))
# sns.scatterplot(x='x',y='y',hue=train4['topic'], data=mapping2, ax=ax, legend='full')
# # plt.legend(loc='best')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f5ca00a4b38>




![png](output_126_1.png)



```python
# from sklearn.cluster import KMeans
# y_pred = KMeans(n_clusters=21, random_state=1337).fit_predict(mapping_mean)

```


```python
# fig, ax = plt.subplots(1,1,figsize=(15,10))
# # sns.scatterplot(x='x',y='y',hue='target', data=mapping2, ax=ax, legend='full')
# ax.scatter(mapping_tsne[:,0], mapping_tsne[:,1], c=y_pred)
# plt.legend(loc='best')
```

    W0811 09:03:16.939636 140037554907008 legend.py:1289] No handles with labels found to put in legend.





    <matplotlib.legend.Legend at 0x7f5ca00c4cf8>




![png](output_128_2.png)



```python
# cl_mean = []
# for topic in topics:
#     cl_mean.append(mapping_mean[train4.topic == topic].mean(axis=0))
```


```python
# from sklearn.manifold import TSNE
# tsne = TSNE(n_components=2)
# cl_tsne = tsne.fit_transform(np.array(cl_mean).reshape(-1,300))
```


```python
# plt.scatter(cl_tsne[:,0], cl_tsne[:,1], c=range(21))
```




    <matplotlib.collections.PathCollection at 0x7f5c9f530908>




![png](output_131_1.png)



```python
# from google.colab import files
# files.download('submission/deep_att_lstm.csv')
```
